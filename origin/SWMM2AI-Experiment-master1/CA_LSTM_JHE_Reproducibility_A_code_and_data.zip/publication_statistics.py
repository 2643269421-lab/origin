"""Paired statistical tests for fixed-seed model comparisons."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from scipy import stats


def paired_wilcoxon(
    first: Sequence[float], second: Sequence[float], *, alternative: str = "two-sided"
) -> dict[str, float | int | str]:
    a = np.asarray(first, dtype=float)
    b = np.asarray(second, dtype=float)
    if a.shape != b.shape:
        raise ValueError("paired samples must have the same shape")
    finite = np.isfinite(a) & np.isfinite(b)
    a, b = a[finite], b[finite]
    if len(a) == 0:
        raise ValueError("paired samples contain no finite pairs")
    differences = a - b
    nonzero = differences[~np.isclose(differences, 0)]
    if len(nonzero):
        ranks = stats.rankdata(np.abs(nonzero))
        positive = float(ranks[nonzero > 0].sum())
        negative = float(ranks[nonzero < 0].sum())
        rank_biserial = (positive - negative) / (positive + negative)
    else:
        rank_biserial = 0.0
    if np.allclose(differences, 0):
        statistic, p_value = 0.0, 1.0
    else:
        result = stats.wilcoxon(a, b, alternative=alternative)
        statistic, p_value = float(result.statistic), float(result.pvalue)
    return {
        "statistic": statistic,
        "p_value": p_value,
        "n_pairs": int(len(a)),
        "median_difference": float(np.median(differences)),
        "mean_difference": float(np.mean(differences)),
        "rank_biserial": float(rank_biserial),
        "direction": "first-minus-second",
    }


def holm_adjust(p_values: Sequence[float]) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError("p-values must be a finite one-dimensional sequence")
    if np.any((values < 0) | (values > 1)):
        raise ValueError("p-values must be between zero and one")
    order = np.argsort(values)
    sorted_values = values[order]
    adjusted_sorted = np.maximum.accumulate(
        (len(values) - np.arange(len(values))) * sorted_values
    )
    adjusted_sorted = np.minimum(adjusted_sorted, 1.0)
    adjusted = np.empty_like(adjusted_sorted)
    adjusted[order] = adjusted_sorted
    return adjusted


def paired_test_table(
    seed_metrics: pd.DataFrame, *, metric: str,
    comparisons: Sequence[tuple[str, str]],
) -> pd.DataFrame:
    required = {"Model", "Seed", metric}
    missing = required - set(seed_metrics.columns)
    if missing:
        raise ValueError(f"seed metrics missing columns: {sorted(missing)}")
    rows: list[dict] = []
    for first_model, second_model in comparisons:
        first = seed_metrics.loc[
            seed_metrics["Model"] == first_model, ["Seed", metric]
        ].rename(columns={metric: "first"})
        second = seed_metrics.loc[
            seed_metrics["Model"] == second_model, ["Seed", metric]
        ].rename(columns={metric: "second"})
        paired = first.merge(second, on="Seed", how="inner", validate="one_to_one")
        result = paired_wilcoxon(paired["first"], paired["second"])
        rows.append({
            "metric": metric, "first_model": first_model,
            "second_model": second_model, **result,
        })
    output = pd.DataFrame(rows)
    output["p_value_holm"] = holm_adjust(output["p_value"])
    return output
