# JHE cross-node revision design

## Objective

Test whether the temporal non-anticipation effect observed at outlet-adjacent SN_001 is stable at hydraulically distinct locations, without selecting nodes from model performance.

## Prespecified node rule

- Mid-network confluence: among junctions with at least two direct upstream conduits and 8–12 downstream hops, choose the largest contributing area (SN_032).
- Upstream target: choose the longest downstream path (SN_044).

The audit uses only the SWMM input topology and attributes. It is written before added-node model evaluation.

## Experiment

- Replay the exact 200 development storms and four extreme sets (15 events each at T=20,30,50,100 years) at each added node.
- Train LSTM, RandomMaskLSTM, and CA-LSTM with the same ten seeds, splits, train-only scaling, 64 hidden units, two layers, 100-epoch maximum, and patience 15.
- Evaluate held-out development events and all extreme events.
- Use seed means as paired units. Test CA-LSTM vs LSTM and CA-LSTM vs RandomMaskLSTM for RMSE and DASR; Holm-adjust the four comparisons within each metric and report paired rank-biserial effects.

## Interpretation boundary

The causal mask is a temporal information-flow constraint. It does not impose mass conservation, conduit topology, or the dynamic-wave equations. A node-by-metric reversal must be reported rather than collapsed into a universal-superiority claim.
