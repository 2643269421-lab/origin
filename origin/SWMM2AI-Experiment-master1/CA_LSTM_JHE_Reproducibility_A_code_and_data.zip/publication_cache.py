"""Build reproducible raw SWMM event caches for publication experiments."""

from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from publication_config import TRAIN_MAX_RETURN_PERIOD
from publication_data import save_event_cache
from publication_data import load_event_cache
from swmm.rainfall.generator import RainfallGenerator
from swmm.simulator import SWMMSimulator


def _simulate_group(
    *, generator: RainfallGenerator, simulator: SWMMSimulator,
    requested_events: int, sequence_length: int, time_step_minutes: int,
    min_duration_hours: float, max_duration_hours: float,
    max_return_period: int | None = None, return_period: int | None = None,
) -> tuple[np.ndarray, np.ndarray, list[dict]]:
    rainfall_events = generator.generate_multiple_events(
        n_events=requested_events, seq_length=sequence_length,
        min_duration=min_duration_hours, max_duration=max_duration_hours,
        rain_type="chicago", max_return_period=max_return_period,
        return_period=return_period,
    )
    water_events: list[np.ndarray] = []
    failures: list[dict] = []
    for event_index, rainfall in enumerate(rainfall_events):
        result = simulator.run_swmm_simulation(
            rainfall_mm_h=np.asarray(rainfall, dtype=float),
            time_step_min=time_step_minutes,
        )
        values = None if result is None else result.get("values")
        if values is None:
            failures.append({"event_index": event_index, "reason": "empty SWMM result"})
            continue
        values = np.asarray(values, dtype=float).reshape(-1)
        if len(values) != sequence_length or not np.isfinite(values).all():
            failures.append({
                "event_index": event_index,
                "reason": f"invalid output shape or values: {values.shape}",
            })
            continue
        water_events.append(values)

    if failures:
        details = "; ".join(
            f"event {item['event_index']}: {item['reason']}" for item in failures
        )
        raise RuntimeError(
            f"SWMM generated {len(water_events)}/{requested_events} valid events; {details}"
        )
    return np.asarray(rainfall_events, dtype=float), np.asarray(water_events), failures


def build_event_caches(
    *, output_dir: str | Path, template_path: str | Path, seed: int,
    n_train: int, extreme_return_periods: tuple[int, ...],
    n_test_per_return_period: int, sequence_length: int,
    time_step_minutes: int, min_duration_hours: float = 1.0,
    max_duration_hours: float = 6.0,
) -> Path:
    """Generate raw events, fail on any missing run, and write a hash manifest."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    template = Path(template_path).resolve()
    if not template.is_file():
        raise FileNotFoundError(f"SWMM template not found: {template}")
    if n_train <= 0 or n_test_per_return_period <= 0:
        raise ValueError("event counts must be positive")

    np.random.seed(seed)
    generator = RainfallGenerator(time_step_min=time_step_minutes)
    simulator = SWMMSimulator(
        template_inp_path=str(template), output_dir=str(destination / "swmm_work"),
        output_element="SN_001", output_type="node", output_variable="depth",
    )
    common_metadata = {
        "seed": seed, "sequence_length": sequence_length,
        "time_step_minutes": time_step_minutes, "rain_type": "chicago",
        "min_duration_hours": min_duration_hours,
        "max_duration_hours": max_duration_hours, "template_path": str(template),
    }
    manifest: dict = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "files": {},
    }

    train_rain, train_water, train_failures = _simulate_group(
        generator=generator, simulator=simulator, requested_events=n_train,
        sequence_length=sequence_length, time_step_minutes=time_step_minutes,
        min_duration_hours=min_duration_hours,
        max_duration_hours=max_duration_hours,
        max_return_period=TRAIN_MAX_RETURN_PERIOD,
    )
    train_name = "train_events.npz"
    train_metadata = {
        **common_metadata, "group": "training",
        "max_return_period": TRAIN_MAX_RETURN_PERIOD,
        "requested_events": n_train, "valid_events": len(train_rain),
        "failures": train_failures,
    }
    train_path = destination / train_name
    digest = save_event_cache(train_path, train_rain, train_water, train_metadata)
    manifest["files"][train_name] = {
        "sha256": digest, "size_bytes": train_path.stat().st_size,
    }

    for return_period in extreme_return_periods:
        test_rain, test_water, test_failures = _simulate_group(
            generator=generator, simulator=simulator,
            requested_events=n_test_per_return_period,
            sequence_length=sequence_length, time_step_minutes=time_step_minutes,
            min_duration_hours=min_duration_hours,
            max_duration_hours=max_duration_hours,
            return_period=int(return_period),
        )
        name = f"extreme_T{return_period}.npz"
        metadata = {
            **common_metadata, "group": "extreme_test",
            "return_period": int(return_period),
            "requested_events": n_test_per_return_period,
            "valid_events": len(test_rain), "failures": test_failures,
        }
        path = destination / name
        digest = save_event_cache(path, test_rain, test_water, metadata)
        manifest["files"][name] = {
            "sha256": digest, "size_bytes": path.stat().st_size,
        }

    manifest_path = destination / "cache_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return manifest_path


def build_node_caches(*, source_cache_dir: str | Path, output_dir: str | Path,
                      template_path: str | Path, target_node: str) -> Path:
    """Replay an existing rainfall cache at another node without regenerating rainfall."""
    source = Path(source_cache_dir); destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    template = Path(template_path).resolve()
    simulator = SWMMSimulator(template_inp_path=str(template),
                              output_dir=str(destination / "swmm_work"),
                              output_element=target_node, output_type="node",
                              output_variable="depth")
    template_digest = sha256(template.read_bytes()).hexdigest()
    manifest = {"created_utc": datetime.now(timezone.utc).isoformat(),
                "target_node": target_node, "template_sha256": template_digest,
                "files": {}}
    inputs = [source / "train_events.npz", *sorted(source.glob("extreme_T*.npz"))]
    if len(inputs) != 5: raise ValueError(f"expected five source caches, found {len(inputs)}")
    for source_path in inputs:
        rain, _, metadata = load_event_cache(source_path)
        outputs = []
        for index, event in enumerate(rain):
            result = simulator.run_swmm_simulation(event, time_step_min=int(metadata["time_step_minutes"]))
            values = None if result is None else result.get("values")
            values = None if values is None else np.asarray(values, dtype=float).reshape(-1)
            if values is None or values.shape != event.shape or not np.isfinite(values).all():
                raise RuntimeError(f"{target_node} {source_path.name} event {index} failed")
            outputs.append(values)
        target_metadata = {**metadata, "target_node": target_node,
                           "template_sha256": template_digest,
                           "source_cache_sha256": sha256(source_path.read_bytes()).hexdigest()}
        target_path = destination / source_path.name
        digest = save_event_cache(target_path, rain, np.asarray(outputs), target_metadata)
        manifest["files"][source_path.name] = {"sha256": digest,
                                              "source_sha256": target_metadata["source_cache_sha256"],
                                              "events": len(rain)}
    manifest_path = destination / "cache_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest_path
