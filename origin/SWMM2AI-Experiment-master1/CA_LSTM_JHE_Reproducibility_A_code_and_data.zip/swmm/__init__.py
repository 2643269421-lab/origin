"""Project SWMM helpers with access to the installed SWMM Toolkit namespace."""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)
