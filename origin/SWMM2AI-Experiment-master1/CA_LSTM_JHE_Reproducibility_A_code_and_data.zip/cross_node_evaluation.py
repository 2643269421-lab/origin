"""Evaluate cross-node checkpoints with node-aware provenance and paired inference."""

from __future__ import annotations
import argparse
from hashlib import sha256
from pathlib import Path
import pandas as pd
import torch

from publication_config import ModelSpec
from publication_data import load_event_cache
from publication_evaluation import _metric_rows, _predict_events, compute_hydraulic_characteristics
from publication_statistics import holm_adjust, paired_test_table
from publication_training import TrainingSettings, build_model

METRICS = ["RMSE", "MAE", "NSE", "R2", "PeakError", "PeakIdxError", "DASR", "NRMSE"]
COMPARISONS = (("CA-LSTM", "LSTM"), ("CA-LSTM", "RandomMaskLSTM"))


def _load_model(path, node, digest):
    c = torch.load(path, map_location="cpu", weights_only=False)
    required = {"model_spec", "settings", "seed", "fingerprint_payload", "model_state_dict"}
    if not required.issubset(c): raise ValueError(f"checkpoint lacks metadata: {path}")
    provenance = c["fingerprint_payload"].get("provenance", {})
    if provenance.get("target_node") != node or provenance.get("cache_sha256") != digest:
        raise ValueError(f"checkpoint provenance mismatch: {path}")
    spec = ModelSpec(**c["model_spec"]); settings = TrainingSettings(**c["settings"])
    model = build_model(spec, hidden_size=settings.hidden_size, num_layers=settings.num_layers,
                        dropout=settings.dropout)
    model.load_state_dict(c["model_state_dict"])
    return c, spec, model


def evaluate_cross_nodes(experiment_root, output_dir):
    root, out = Path(experiment_root), Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    rows, hydraulics = [], []
    nodes = sorted(p for p in root.iterdir() if (p/"data_cache/train_events.npz").is_file())
    for node_dir in nodes:
        node, cache = node_dir.name, node_dir/"data_cache"
        train_path = cache/"train_events.npz"; digest = sha256(train_path.read_bytes()).hexdigest()
        train_rain, train_water, train_meta = load_event_cache(train_path)
        extremes = sorted(cache.glob("extreme_T*.npz"))
        for name, path in [("training_RP_le_10", train_path), *[(f"extreme_T{load_event_cache(p)[2]['return_period']}", p) for p in extremes]]:
            rain, water, meta = load_event_cache(path)
            h = compute_hydraulic_characteristics(rain, water, time_step_minutes=int(meta["time_step_minutes"]))
            h.insert(0, "Dataset", name); h.insert(0, "Node", node); hydraulics.append(h)
        for cp in sorted((node_dir/"training").glob("*.pth")):
            c, spec, model = _load_model(cp, node, digest); seed = int(c["seed"]); payload = c["fingerprint_payload"]
            idx = payload["split_indices"]["test"]
            pred = _predict_events(model, train_rain[idx], payload["rain_scaler"], payload["water_scaler"])
            current = _metric_rows(model_name=spec.name, seed=seed, dataset_name="in_distribution",
                                   predictions=pred, targets=train_water[idx], event_names=idx)
            for row in current: row["Node"] = node
            rows.extend(current)
            for path in extremes:
                rain, water, meta = load_event_cache(path); name = f"extreme_T{meta['return_period']}"
                pred = _predict_events(model, rain, payload["rain_scaler"], payload["water_scaler"])
                current = _metric_rows(model_name=spec.name, seed=seed, dataset_name=name,
                                       predictions=pred, targets=water)
                for row in current: row["Node"] = node
                rows.extend(current)
    events = pd.DataFrame(rows); events.to_csv(out/"cross_node_event_metrics.csv", index=False, encoding="utf-8-sig")
    pd.concat(hydraulics, ignore_index=True).to_csv(out/"cross_node_hydraulic_characteristics.csv", index=False, encoding="utf-8-sig")
    seeds = events.groupby(["Node", "Model", "Seed", "Dataset"], as_index=False)[METRICS].mean(numeric_only=True)
    extreme = events[events.Dataset.str.startswith("extreme_T")].groupby(["Node", "Model", "Seed"], as_index=False)[METRICS].mean(numeric_only=True)
    extreme["Dataset"] = "extreme_all"; seeds = pd.concat([seeds, extreme], ignore_index=True)
    seeds.to_csv(out/"cross_node_seed_metrics.csv", index=False, encoding="utf-8-sig")
    tables = []
    for node in sorted(seeds.Node.unique()):
        source = seeds[(seeds.Node == node) & (seeds.Dataset == "extreme_all")]
        for metric in ("RMSE", "DASR"):
            t = paired_test_table(source, metric=metric, comparisons=COMPARISONS); t.insert(0, "Node", node); tables.append(t)
    paired = pd.concat(tables, ignore_index=True)
    for metric, idx in paired.groupby("metric").groups.items():
        paired.loc[idx, "p_value_holm"] = holm_adjust(paired.loc[idx, "p_value"].to_numpy(float))
    paired.to_csv(out/"cross_node_paired_tests.csv", index=False, encoding="utf-8-sig")
    return events, seeds, paired


def main():
    p=argparse.ArgumentParser(); p.add_argument("--experiment-root",required=True); p.add_argument("--output",required=True); a=p.parse_args()
    e,s,t=evaluate_cross_nodes(a.experiment_root,a.output); print(f"event_rows={len(e)} seed_rows={len(s)} paired_tests={len(t)}")


if __name__ == "__main__": main()
