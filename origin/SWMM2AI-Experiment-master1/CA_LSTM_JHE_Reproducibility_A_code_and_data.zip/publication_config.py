"""Single source of truth for publication experiment constants."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelSpec:
    """Architecture/loss definition used in the paired ablation study."""

    name: str
    architecture: str
    lambda_smooth: float = 0.0
    lambda_peak: float = 0.0
    peak_temperature: float = 0.1


MAIN_MODEL_SPECS = {
    "LSTM": ModelSpec("LSTM", "lstm"),
    "AttentionLSTM": ModelSpec("AttentionLSTM", "attention"),
    "RandomMaskLSTM": ModelSpec("RandomMaskLSTM", "random_mask"),
    "CA-LSTM": ModelSpec("CA-LSTM", "causal_attention"),
    "CA+SmoothLoss": ModelSpec(
        "CA+SmoothLoss", "causal_attention", lambda_smooth=0.01
    ),
    "CA+PeakTimeLoss": ModelSpec(
        "CA+PeakTimeLoss", "causal_attention", lambda_peak=0.05
    ),
    "PCCA-LSTM": ModelSpec(
        "PCCA-LSTM", "causal_attention", lambda_smooth=0.01, lambda_peak=0.05
    ),
}

APPENDIX_MODEL_SPECS = {"GRU": ModelSpec("GRU", "gru")}

SEEDS = (42, 123, 456, 789, 1024, 2048, 3072, 4096, 5120, 6144)
N_TRAIN_EVENTS = 200
TRAIN_MAX_RETURN_PERIOD = 10
EXTREME_RETURN_PERIODS = (20, 30, 50, 100)
N_TEST_EVENTS_PER_RETURN_PERIOD = 15
SEQUENCE_LENGTH = 288
TIME_STEP_MINUTES = 5
MAX_EPOCHS = 100
BATCH_SIZE = 32
LEARNING_RATE = 0.001
EARLY_STOPPING_PATIENCE = 15
