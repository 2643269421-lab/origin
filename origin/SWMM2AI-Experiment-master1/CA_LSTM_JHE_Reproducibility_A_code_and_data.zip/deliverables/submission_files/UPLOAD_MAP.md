# Submission Upload Map

Upload the manuscript and response as document items. Upload each TIFF as a separate
`Figure` item using the descriptions below. The number and wording in every file name,
figure heading, and manuscript caption are aligned.

| Order | Item type | Description | File name |
|---:|---|---|---|
| 1 | Manuscript | Manuscript | `Manuscript_CA-LSTM_Revised.docx` |
| 2 | Response | Response to Editor | `Response_to_Editor.docx` |
| 3 | Figure | Fig. 1 | `figures/Fig1_LeakageFreeExperimentalFrameworkAndEvidenceFlow.tif` |
| 4 | Figure | Fig. 2 | `figures/Fig2_ModelPerformanceAcrossExtremeRainfallReturnPeriods.tif` |
| 5 | Figure | Fig. 3 | `figures/Fig3_OverallRMSEComparisonSevenModels.tif` |
| 6 | Figure | Fig. 4 | `figures/Fig4_PairedSeedComparisonLSTM_CA-LSTM.tif` |
| 7 | Figure | Fig. 5 | `figures/Fig5_LossRegularizationAblationCausalArchitecture.tif` |
| 8 | Figure | Fig. 6 | `figures/Fig6_PerformanceCompleteObservedRainfallEvents.tif` |

Do not type the `.tif` suffix into the description field. The suffix is only the image-file
format. In the submission system, use `Fig. 1`, `Fig. 2`, and so on as the descriptions.

