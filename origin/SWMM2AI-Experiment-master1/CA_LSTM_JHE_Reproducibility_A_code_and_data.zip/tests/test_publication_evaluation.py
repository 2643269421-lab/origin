from pathlib import Path

import numpy as np
import pandas as pd

from publication_evaluation import (
    audit_real_data,
    compute_hydraulic_characteristics,
    compute_metrics,
    select_observed_columns,
)


def test_perfect_series_metrics() -> None:
    y = np.array([0.0, 1.0, 2.0, 1.0])
    metrics = compute_metrics(y, y)
    assert metrics["RMSE"] == 0.0
    assert metrics["MAE"] == 0.0
    assert metrics["NSE"] == 1.0
    assert metrics["DASR"] == 100.0
    assert metrics["PeakIdxError"] == 0


def test_nse_is_undefined_for_numerically_constant_target() -> None:
    target = np.array([0.1, np.nextafter(0.1, 1.0), 0.1])
    metrics = compute_metrics(np.zeros_like(target), target)
    assert np.isnan(metrics["NSE"])


def test_huzhou_excel_columns_are_selected_explicitly() -> None:
    columns = ["时间", "雨强(mm/hr)", "HUZU_STORM_L_01_液位", "其他液位"]
    assert select_observed_columns(columns) == (
        "雨强(mm/hr)", "HUZU_STORM_L_01_液位"
    )


def test_hydraulic_characteristics_report_rainfall_to_depth_lag() -> None:
    rain = np.array([[0.0, 5.0, 1.0, 0.0]])
    depth = np.array([[0.0, 1.0, 3.0, 2.0]])
    output = compute_hydraulic_characteristics(rain, depth, time_step_minutes=5)
    assert output.loc[0, "RainPeakIdx"] == 1
    assert output.loc[0, "DepthPeakIdx"] == 2
    assert output.loc[0, "ResponseLagMinutes"] == 5


def test_real_data_audit_records_included_and_excluded_files(tmp_path: Path) -> None:
    good = pd.DataFrame({
        "时间": ["00:00", "00:05"],
        "雨强(mm/hr)": [0.0, 2.0],
        "HUZU_STORM_L_01_液位": [0.1, 0.2],
    })
    bad = pd.DataFrame({"时间": ["00:00"], "不明确雨量": [1.0], "液位": [0.2]})
    good.to_excel(tmp_path / "good.xlsx", index=False)
    bad.to_excel(tmp_path / "bad.xlsx", index=False)

    output = tmp_path / "audit.csv"
    audit = audit_real_data(tmp_path, output, expected_rows=2)
    assert output.is_file()
    assert set(audit["status"]) == {"included", "excluded"}
    assert audit.loc[audit["file"] == "bad.xlsx", "reason"].iloc[0]


def test_real_data_audit_excludes_incomplete_paired_series(tmp_path: Path) -> None:
    frame = pd.DataFrame({
        "雨强(mm/hr)": [0.0, np.nan, 2.0],
        "HUZU_STORM_L_01_液位": [0.1, 0.2, 0.3],
    })
    frame.to_excel(tmp_path / "incomplete.xlsx", index=False)
    audit = audit_real_data(tmp_path, tmp_path / "audit.csv", expected_rows=3)
    assert audit.loc[0, "status"] == "excluded"
    assert "2 paired numeric observations; expected 3" in audit.loc[0, "reason"]
