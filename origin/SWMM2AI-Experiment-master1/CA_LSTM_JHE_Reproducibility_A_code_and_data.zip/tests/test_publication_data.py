from pathlib import Path

import numpy as np

from publication_data import (
    load_event_cache,
    make_split_indices,
    prepare_split,
    save_event_cache,
)


def test_scaler_uses_training_events_only() -> None:
    """Catches validation/test leakage into the fitted scaler extrema."""
    rain = np.array([[0.0, 1.0], [2.0, 3.0], [100.0, 200.0]])
    depth = rain / 10.0

    prepared = prepare_split(
        rain,
        depth,
        train_idx=[0, 1],
        val_idx=[2],
        test_idx=[],
    )

    assert prepared.rain_scaler.data_max_[0] == 3.0
    assert prepared.water_scaler.data_max_[0] == 0.3
    assert prepared.val_x.max() > 1.0
    assert prepared.val_y.max() > 1.0


def test_same_seed_returns_same_disjoint_indices() -> None:
    """Catches nondeterministic or overlapping event assignments."""
    first = make_split_indices(n_events=200, seed=42)
    second = make_split_indices(n_events=200, seed=42)

    assert first == second
    assert len(first["train"]) == 160
    assert len(first["val"]) == 20
    assert len(first["test"]) == 20
    assert set(first["train"]).isdisjoint(first["val"])
    assert set(first["train"]).isdisjoint(first["test"])
    assert set(first["val"]).isdisjoint(first["test"])


def test_different_seed_changes_event_assignment() -> None:
    """Catches accidentally hard-coded split indices."""
    first = make_split_indices(n_events=30, seed=42)
    second = make_split_indices(n_events=30, seed=123)

    assert first != second


def test_event_cache_round_trip_preserves_arrays_and_metadata(tmp_path: Path) -> None:
    """Catches cache writes that lose event provenance or alter array values."""
    cache_path = tmp_path / "events.npz"
    rain = np.arange(12, dtype=float).reshape(3, 4)
    depth = rain / 100.0
    metadata = {
        "seed": 20260820,
        "return_period": 100,
        "event_ids": ["e0", "e1", "e2"],
    }

    digest = save_event_cache(cache_path, rain, depth, metadata)
    loaded_rain, loaded_depth, loaded_metadata = load_event_cache(cache_path)

    assert len(digest) == 64
    np.testing.assert_array_equal(loaded_rain, rain)
    np.testing.assert_array_equal(loaded_depth, depth)
    assert loaded_metadata == metadata


def test_prepare_split_rejects_overlapping_indices() -> None:
    """Catches reuse of an event in more than one data partition."""
    rain = np.arange(20, dtype=float).reshape(5, 4)
    depth = rain / 10.0

    try:
        prepare_split(rain, depth, train_idx=[0, 1], val_idx=[1, 2], test_idx=[3])
    except ValueError as exc:
        assert "overlap" in str(exc).lower()
    else:
        raise AssertionError("overlapping event indices were accepted")
