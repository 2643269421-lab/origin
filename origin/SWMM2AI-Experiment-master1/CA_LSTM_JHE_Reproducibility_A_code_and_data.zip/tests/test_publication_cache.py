import json
from pathlib import Path

from publication_cache import build_event_caches
from publication_data import load_event_cache


def test_small_cache_build_records_every_requested_event(tmp_path: Path) -> None:
    """Catches silent SWMM failures and caches with incorrect sample counts."""
    project_root = Path(__file__).resolve().parents[1]

    manifest_path = build_event_caches(
        output_dir=tmp_path,
        template_path=project_root / "template.inp",
        seed=7,
        n_train=3,
        extreme_return_periods=(20,),
        n_test_per_return_period=1,
        sequence_length=48,
        time_step_minutes=5,
        min_duration_hours=1.0,
        max_duration_hours=1.0,
    )

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    train_rain, train_depth, train_meta = load_event_cache(tmp_path / "train_events.npz")
    test_rain, test_depth, test_meta = load_event_cache(tmp_path / "extreme_T20.npz")

    assert train_rain.shape == train_depth.shape == (3, 48)
    assert test_rain.shape == test_depth.shape == (1, 48)
    assert train_meta["requested_events"] == train_meta["valid_events"] == 3
    assert test_meta["requested_events"] == test_meta["valid_events"] == 1
    assert manifest["files"]["train_events.npz"]["sha256"]
    assert manifest["files"]["extreme_T20.npz"]["sha256"]
