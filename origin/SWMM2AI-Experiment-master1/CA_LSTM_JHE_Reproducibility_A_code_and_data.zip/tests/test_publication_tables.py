from pathlib import Path

import pandas as pd

from publication_tables import build_publication_tables


def test_tables_use_seed_level_rows_and_main_model_order(tmp_path: Path) -> None:
    models = [
        "LSTM", "AttentionLSTM", "RandomMaskLSTM", "CA-LSTM",
        "CA+SmoothLoss", "CA+PeakTimeLoss", "PCCA-LSTM",
    ]
    rows = []
    for seed in (1, 2):
        for i, model in enumerate(models):
            for dataset in ("extreme_T100", "real_observed"):
                rows.append({
                    "Model": model, "Seed": seed, "Dataset": dataset,
                    "RMSE": 0.01 + i / 1000, "DASR": 50 + i,
                    "PeakError": -0.01, "PeakIdxError": 2 + i,
                    "NSE": 0.9,
                })
    outputs = build_publication_tables(pd.DataFrame(rows), tmp_path)
    extreme = pd.read_csv(outputs["extreme"])
    observed = pd.read_csv(outputs["observed"])
    assert extreme["Model"].tolist() == models
    assert observed["Model"].tolist() == models
    assert (extreme["N_seeds"] == 2).all()
    assert (observed["N_seeds"] == 2).all()
