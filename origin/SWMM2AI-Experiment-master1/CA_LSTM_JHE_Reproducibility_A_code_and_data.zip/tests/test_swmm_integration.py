from pathlib import Path

import numpy as np

from swmm.simulator import SWMMSimulator


def test_one_event_runs_with_cross_platform_engine(tmp_path: Path) -> None:
    """Catches a Linux regression where only the bundled Windows EXE is supported."""
    project_root = Path(__file__).resolve().parents[1]
    simulator = SWMMSimulator(
        template_inp_path=str(project_root / "template.inp"),
        output_dir=str(tmp_path),
        output_element="SN_001",
        output_type="node",
        output_variable="depth",
    )
    rainfall = np.zeros(288, dtype=float)
    rainfall[24:36] = 5.0

    result = simulator.run_swmm_simulation(rainfall_mm_h=rainfall)

    assert result is not None
    assert result["id"] == "SN_001"
    assert len(result["values"]) == 288
    assert np.isfinite(result["values"]).all()
