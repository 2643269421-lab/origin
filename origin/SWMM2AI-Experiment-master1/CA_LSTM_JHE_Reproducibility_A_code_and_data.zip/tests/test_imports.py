import importlib

import pytest


@pytest.mark.parametrize(
    "module_name",
    [
        "numpy",
        "pandas",
        "scipy",
        "sklearn",
        "matplotlib",
        "openpyxl",
        "swmm_api",
        "torch",
    ],
)
def test_publication_dependency_imports(module_name: str) -> None:
    """Catches an incomplete environment declaration before a long experiment starts."""
    assert importlib.import_module(module_name) is not None
