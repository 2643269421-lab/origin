import os
from pathlib import Path

from swmm.simulator import find_swmm_executable


def test_explicit_swmm_path_wins(tmp_path: Path, monkeypatch) -> None:
    """Catches a regression where an explicit, executable runtime is ignored."""
    executable = tmp_path / "swmm5"
    executable.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    executable.chmod(0o755)
    monkeypatch.setenv("SWMM_EXECUTABLE", str(executable))

    assert find_swmm_executable() == str(executable)


def test_relative_executable_is_resolved_from_path(tmp_path: Path, monkeypatch) -> None:
    """Catches a regression where POSIX SWMM executables on PATH are not found."""
    executable = tmp_path / "swmm5"
    executable.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    executable.chmod(0o755)
    monkeypatch.delenv("SWMM_EXECUTABLE", raising=False)
    monkeypatch.setenv("PATH", f"{tmp_path}{os.pathsep}{os.environ.get('PATH', '')}")

    assert find_swmm_executable(candidates=["swmm5"]) == str(executable)


def test_windows_binary_is_not_selected_on_linux(
    tmp_path: Path, monkeypatch
) -> None:
    """Catches trying to execute the bundled Windows PE file on Linux."""
    executable = tmp_path / "runswmm.exe"
    executable.write_bytes(b"MZ")
    executable.chmod(0o755)
    monkeypatch.delenv("SWMM_EXECUTABLE", raising=False)
    monkeypatch.setenv("PATH", str(tmp_path))

    value = find_swmm_executable(candidates=["runswmm.exe"])

    assert value is None


def test_non_executable_explicit_path_is_rejected(
    tmp_path: Path, monkeypatch
) -> None:
    """Catches accepting a file that cannot be launched as SWMM."""
    executable = tmp_path / "swmm5"
    executable.write_text("not executable", encoding="utf-8")
    executable.chmod(0o644)
    monkeypatch.setenv("SWMM_EXECUTABLE", str(executable))
    monkeypatch.setenv("PATH", "")

    assert find_swmm_executable(candidates=[]) is None
