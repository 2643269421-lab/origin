import json
from pathlib import Path

import pandas as pd

from publication_figures import FIGURE_CAPTIONS, generate_publication_figures, required_columns


def test_extreme_trend_schema() -> None:
    assert required_columns("seed_metrics") == {
        "Model", "Seed", "Dataset", "RMSE", "DASR", "PeakIdxError"
    }


def test_figure_filenames_and_internal_numbers_match(tmp_path: Path) -> None:
    rows = []
    models = [
        "LSTM", "AttentionLSTM", "RandomMaskLSTM", "CA-LSTM",
        "CA+SmoothLoss", "CA+PeakTimeLoss", "PCCA-LSTM",
    ]
    for seed in (1, 2):
        for model_index, model in enumerate(models):
            for dataset, offset in (("extreme_T20", 0.0), ("extreme_T100", 0.01),
                                    ("extreme_all", 0.005), ("real_observed", 0.02)):
                rows.append({
                    "Model": model, "Seed": seed, "Dataset": dataset,
                    "RMSE": 0.03 + model_index * 0.002 + offset,
                    "DASR": 55 + model_index * 2 - offset,
                    "PeakIdxError": 8 - model_index * 0.5 + offset,
                })
    seed_metrics = pd.DataFrame(rows)
    manifest_path = generate_publication_figures(seed_metrics, tmp_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert len(manifest["figures"]) == 6
    for number, caption in FIGURE_CAPTIONS.items():
        entry = manifest["figures"][str(number)]
        assert entry["caption"] == caption
        assert Path(entry["png"]).name.startswith(f"Fig{number}_")
        assert Path(entry["tif"]).name.startswith(f"Fig{number}_")
        assert (tmp_path / Path(entry["png"]).name).is_file()
        assert (tmp_path / Path(entry["tif"]).name).is_file()
