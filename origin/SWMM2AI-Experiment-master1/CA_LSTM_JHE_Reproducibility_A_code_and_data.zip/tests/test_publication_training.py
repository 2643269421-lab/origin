from pathlib import Path

import numpy as np
import torch

from attention import RandomMaskAttentionLSTM

from publication_config import (
    APPENDIX_MODEL_SPECS,
    EARLY_STOPPING_PATIENCE,
    MAIN_MODEL_SPECS,
    MAX_EPOCHS,
    ModelSpec,
)
from publication_data import prepare_split
from publication_training import (
    TrainingSettings,
    _criterion,
    build_model,
    checkpoint_matches,
    train_one,
)


def test_main_text_contains_exactly_seven_models() -> None:
    assert list(MAIN_MODEL_SPECS) == [
        "LSTM",
        "AttentionLSTM",
        "RandomMaskLSTM",
        "CA-LSTM",
        "CA+SmoothLoss",
        "CA+PeakTimeLoss",
        "PCCA-LSTM",
    ]


def test_gru_is_appendix_only() -> None:
    assert "GRU" not in MAIN_MODEL_SPECS
    assert list(APPENDIX_MODEL_SPECS) == ["GRU"]


def test_full_run_defaults_match_the_archived_experiment() -> None:
    settings = TrainingSettings()
    assert MAX_EPOCHS == settings.epochs == 100
    assert EARLY_STOPPING_PATIENCE == settings.patience == 15
    assert settings.hidden_size == 64


def test_peak_loss_uses_declared_soft_argmax_temperature() -> None:
    criterion = _criterion(MAIN_MODEL_SPECS["CA+PeakTimeLoss"])
    assert criterion.peak_time.temperature == 0.1


def test_every_spec_produces_sequence_to_sequence_output() -> None:
    x = torch.zeros((2, 12, 1))
    for spec in [*MAIN_MODEL_SPECS.values(), *APPENDIX_MODEL_SPECS.values()]:
        model = build_model(spec, hidden_size=4, num_layers=1, dropout=0.0)
        assert model(x).shape == x.shape


def test_causal_attention_prediction_cannot_see_future_inputs() -> None:
    spec = ModelSpec("CA-LSTM", "causal_attention")
    model = build_model(spec, hidden_size=4, num_layers=1, dropout=0.0).eval()
    first = torch.zeros((1, 12, 1))
    second = first.clone()
    second[:, 8:, :] = 100.0
    with torch.no_grad():
        prediction_a = model(first)
        prediction_b = model(second)
    assert torch.allclose(prediction_a[:, :8], prediction_b[:, :8], atol=1e-6)


def test_random_control_uses_a_fixed_noncausal_permutation() -> None:
    model = RandomMaskAttentionLSTM(hidden_size=4, num_layers=1, dropout=0.0)
    first = model._get_random_order(12, torch.device("cpu"))
    second = model._get_random_order(12, torch.device("cpu"))
    assert torch.equal(first, second)
    assert torch.equal(torch.sort(first).values, torch.arange(12))
    assert not torch.equal(first, torch.arange(12))


def test_checkpoint_fingerprint_rejects_changed_split(tmp_path: Path) -> None:
    rain = np.arange(60, dtype=float).reshape(6, 10)
    water = rain / 10.0
    prepared = prepare_split(
        rain, water, train_idx=[0, 1, 2, 3], val_idx=[4], test_idx=[5]
    )
    settings = TrainingSettings(epochs=1, batch_size=2, hidden_size=4, num_layers=1)
    record = train_one(
        MAIN_MODEL_SPECS["LSTM"], prepared, seed=42,
        output_dir=tmp_path, settings=settings,
    )
    assert checkpoint_matches(Path(record.checkpoint_path), record.config_sha256)
    assert not checkpoint_matches(Path(record.checkpoint_path), "changed")


def test_train_one_writes_history_without_nan(tmp_path: Path) -> None:
    rng = np.random.default_rng(4)
    rain = rng.random((8, 16))
    water = np.cumsum(rain, axis=1) / 16
    prepared = prepare_split(
        rain, water, train_idx=[0, 1, 2, 3, 4, 5], val_idx=[6], test_idx=[7]
    )
    spec = ModelSpec("CA-LSTM", "causal_attention")
    record = train_one(
        spec, prepared, seed=7, output_dir=tmp_path,
        settings=TrainingSettings(
            epochs=2, batch_size=2, hidden_size=4, num_layers=1,
            dropout=0.0, patience=2,
        ),
    )
    history = np.genfromtxt(record.history_path, delimiter=",", names=True)
    assert Path(record.checkpoint_path).is_file()
    assert len(np.atleast_1d(history)) >= 1
    assert np.isfinite(history["train_loss"]).all()
    assert np.isfinite(history["val_loss"]).all()
