from pathlib import Path
import numpy as np
from publication_data import load_event_cache
from publication_nodes import audit_nodes, select_cross_nodes
from publication_statistics import paired_wilcoxon

ROOT=Path(__file__).resolve().parents[1]

def test_topology_only_selection_is_stable():
    audit=audit_nodes(ROOT/"template.inp"); assert len(audit)==49
    assert select_cross_nodes(audit)=={"midstream":"SN_032","upstream":"SN_044"}

def test_added_node_rainfall_is_identical_and_finite():
    source=ROOT/"output/publication_final/data_cache"
    for node in ("SN_032","SN_044"):
        target=ROOT/"output/cross_node"/node/"data_cache"
        for original in [source/"train_events.npz",*sorted(source.glob("extreme_T*.npz"))]:
            rain,_,_=load_event_cache(original); replay,water,meta=load_event_cache(target/original.name)
            assert np.array_equal(rain,replay); assert np.isfinite(water).all(); assert meta["target_node"]==node

def test_rank_biserial_preserves_direction():
    assert paired_wilcoxon([3,4,5],[1,2,3])["rank_biserial"]==1.0
