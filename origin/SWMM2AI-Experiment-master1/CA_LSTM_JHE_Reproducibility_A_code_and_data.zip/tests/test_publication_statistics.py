import numpy as np

from publication_statistics import holm_adjust, paired_wilcoxon


def test_paired_wilcoxon_keeps_seed_pairing() -> None:
    output = paired_wilcoxon(
        [1, 2, 3, 4, 5], [2, 3, 4, 5, 6], alternative="two-sided"
    )
    assert output["n_pairs"] == 5
    assert output["median_difference"] == -1.0
    assert 0 <= output["p_value"] <= 1


def test_holm_adjust_is_monotone_in_sorted_p_values() -> None:
    raw = np.array([0.01, 0.04, 0.03, 0.20])
    adjusted = holm_adjust(raw)
    order = np.argsort(raw)
    assert np.all(np.diff(adjusted[order]) >= 0)
    assert np.all(adjusted >= raw)
    assert np.all(adjusted <= 1)
