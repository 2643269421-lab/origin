"""Train the three prespecified architectures at an added SWMM node."""

from __future__ import annotations
import argparse
from hashlib import sha256
from pathlib import Path

from publication_config import MAIN_MODEL_SPECS
from publication_data import load_event_cache, make_split_indices, prepare_split
from publication_training import TrainingSettings, train_one


def main():
    p = argparse.ArgumentParser(); p.add_argument("--node", required=True)
    p.add_argument("--cache-dir", type=Path, required=True); p.add_argument("--output", type=Path, required=True)
    p.add_argument("--seeds", nargs="+", type=int, required=True)
    p.add_argument("--models", nargs="+", default=["LSTM", "RandomMaskLSTM", "CA-LSTM"])
    p.add_argument("--epochs", type=int, default=100); p.add_argument("--patience", type=int, default=15)
    args = p.parse_args()
    cache_path = args.cache_dir / "train_events.npz"
    rain, water, metadata = load_event_cache(cache_path)
    if metadata.get("target_node") != args.node: raise ValueError("cache/node mismatch")
    provenance = {"target_node": args.node,
                  "cache_sha256": sha256(cache_path.read_bytes()).hexdigest(),
                  "template_sha256": metadata["template_sha256"],
                  "source_cache_sha256": metadata["source_cache_sha256"]}
    settings = TrainingSettings(epochs=args.epochs, patience=args.patience)
    for seed in args.seeds:
        split = make_split_indices(len(rain), seed)
        dataset = prepare_split(rain, water, train_idx=split["train"], val_idx=split["val"], test_idx=split["test"])
        for name in args.models:
            record = train_one(MAIN_MODEL_SPECS[name], dataset, seed, args.output, settings, provenance)
            print(f"{args.node} {name} seed={seed} epoch={record.best_epoch} val={record.best_val_loss:.8g}", flush=True)


if __name__ == "__main__": main()
