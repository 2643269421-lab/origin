"""Deterministic, leakage-free data preparation for publication experiments."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Iterable

import numpy as np
from sklearn.preprocessing import MinMaxScaler


@dataclass(frozen=True)
class PreparedDataset:
    train_x: np.ndarray
    train_y: np.ndarray
    val_x: np.ndarray
    val_y: np.ndarray
    test_x: np.ndarray
    test_y: np.ndarray
    rain_scaler: MinMaxScaler
    water_scaler: MinMaxScaler
    split_indices: dict[str, list[int]]


def make_split_indices(
    n_events: int,
    seed: int,
    train_fraction: float = 0.8,
    val_fraction: float = 0.1,
) -> dict[str, list[int]]:
    """Return deterministic, disjoint event indices for one random seed."""
    if n_events < 3:
        raise ValueError("n_events must be at least 3")
    if not 0 < train_fraction < 1:
        raise ValueError("train_fraction must be between 0 and 1")
    if not 0 <= val_fraction < 1:
        raise ValueError("val_fraction must be between 0 and 1")
    if train_fraction + val_fraction >= 1:
        raise ValueError("train and validation fractions must leave test events")

    permutation = np.random.default_rng(seed).permutation(n_events)
    train_end = int(n_events * train_fraction)
    val_end = train_end + int(n_events * val_fraction)
    return {
        "train": permutation[:train_end].tolist(),
        "val": permutation[train_end:val_end].tolist(),
        "test": permutation[val_end:].tolist(),
    }


def _validate_indices(
    n_events: int,
    train_idx: Iterable[int],
    val_idx: Iterable[int],
    test_idx: Iterable[int],
) -> dict[str, list[int]]:
    split = {
        "train": [int(i) for i in train_idx],
        "val": [int(i) for i in val_idx],
        "test": [int(i) for i in test_idx],
    }
    if not split["train"]:
        raise ValueError("training indices cannot be empty")
    for name, indices in split.items():
        if len(indices) != len(set(indices)):
            raise ValueError(f"duplicate indices in {name} split")
        if any(index < 0 or index >= n_events for index in indices):
            raise ValueError(f"index out of range in {name} split")
    train, val, test = map(set, (split["train"], split["val"], split["test"]))
    if train & val or train & test or val & test:
        raise ValueError("split indices overlap")
    return split


def _transform_events(scaler: MinMaxScaler, values: np.ndarray) -> np.ndarray:
    if len(values) == 0:
        return np.empty(values.shape, dtype=float)
    shape = values.shape
    return scaler.transform(values.reshape(-1, 1)).reshape(shape)


def prepare_split(
    rainfall_events: np.ndarray,
    water_level_events: np.ndarray,
    *,
    train_idx: Iterable[int],
    val_idx: Iterable[int],
    test_idx: Iterable[int],
) -> PreparedDataset:
    """Fit scalers on training events only and transform all partitions."""
    rain = np.asarray(rainfall_events, dtype=float)
    water = np.asarray(water_level_events, dtype=float)
    if rain.ndim != 2 or water.ndim != 2:
        raise ValueError("rainfall and water-level arrays must be two-dimensional")
    if rain.shape != water.shape:
        raise ValueError("rainfall and water-level arrays must have matching shapes")

    split = _validate_indices(len(rain), train_idx, val_idx, test_idx)
    train_rain = rain[split["train"]]
    train_water = water[split["train"]]
    rain_scaler = MinMaxScaler().fit(train_rain.reshape(-1, 1))
    water_scaler = MinMaxScaler().fit(train_water.reshape(-1, 1))

    return PreparedDataset(
        train_x=_transform_events(rain_scaler, train_rain),
        train_y=_transform_events(water_scaler, train_water),
        val_x=_transform_events(rain_scaler, rain[split["val"]]),
        val_y=_transform_events(water_scaler, water[split["val"]]),
        test_x=_transform_events(rain_scaler, rain[split["test"]]),
        test_y=_transform_events(water_scaler, water[split["test"]]),
        rain_scaler=rain_scaler,
        water_scaler=water_scaler,
        split_indices=split,
    )


def save_event_cache(
    path: str | Path,
    rainfall_events: np.ndarray,
    water_level_events: np.ndarray,
    metadata: dict,
) -> str:
    """Write a compressed event cache and return its SHA-256 digest."""
    cache_path = Path(path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        rainfall_events=np.asarray(rainfall_events),
        water_level_events=np.asarray(water_level_events),
        metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False, sort_keys=True)),
    )
    return sha256(cache_path.read_bytes()).hexdigest()


def load_event_cache(path: str | Path) -> tuple[np.ndarray, np.ndarray, dict]:
    """Load arrays and provenance metadata from an event cache."""
    with np.load(Path(path), allow_pickle=False) as cached:
        rainfall = cached["rainfall_events"]
        water = cached["water_level_events"]
        metadata = json.loads(str(cached["metadata_json"].item()))
    return rainfall, water, metadata
