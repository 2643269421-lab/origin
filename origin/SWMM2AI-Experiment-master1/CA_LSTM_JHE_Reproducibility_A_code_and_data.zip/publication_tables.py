"""Create manuscript tables from seed-level metrics only."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


MAIN_MODEL_ORDER = [
    "LSTM", "AttentionLSTM", "RandomMaskLSTM", "CA-LSTM",
    "CA+SmoothLoss", "CA+PeakTimeLoss", "PCCA-LSTM",
]
CROSS_NODE_MODEL_ORDER = ["LSTM", "RandomMaskLSTM", "CA-LSTM"]


def _summary(frame: pd.DataFrame, metrics: list[str]) -> pd.DataFrame:
    grouped = frame.groupby("Model")[metrics].agg(["mean", "std"])
    grouped.columns = [f"{metric}_{stat}" for metric, stat in grouped.columns]
    grouped["N_seeds"] = frame.groupby("Model")["Seed"].nunique()
    grouped = grouped.reindex(MAIN_MODEL_ORDER).reset_index()
    return grouped


def build_publication_tables(
    seed_metrics: pd.DataFrame, output_dir: str | Path
) -> dict[str, Path]:
    required = {
        "Model", "Seed", "Dataset", "RMSE", "DASR", "PeakError",
        "PeakIdxError", "NSE",
    }
    missing = required - set(seed_metrics.columns)
    if missing:
        raise ValueError(f"seed metrics missing columns: {sorted(missing)}")
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)

    extreme_source = seed_metrics[
        (seed_metrics["Dataset"] == "extreme_T100")
        & seed_metrics["Model"].isin(MAIN_MODEL_ORDER)
    ]
    observed_source = seed_metrics[
        (seed_metrics["Dataset"] == "real_observed")
        & seed_metrics["Model"].isin(MAIN_MODEL_ORDER)
    ]
    if extreme_source.empty or observed_source.empty:
        raise ValueError("both extreme_T100 and real_observed seed metrics are required")
    extreme = _summary(
        extreme_source, ["RMSE", "DASR", "PeakError", "PeakIdxError", "NSE"]
    )
    observed = _summary(observed_source, ["DASR", "PeakIdxError"])
    extreme_path = destination / "Table1_Extreme_T100_SeedSummary.csv"
    observed_path = destination / "Table2_Observed_SeedSummary.csv"
    extreme.to_csv(extreme_path, index=False, encoding="utf-8-sig")
    observed.to_csv(observed_path, index=False, encoding="utf-8-sig")
    return {"extreme": extreme_path, "observed": observed_path}


def build_cross_node_table(seed_metrics: pd.DataFrame, output_dir: str | Path) -> Path:
    metrics = ["RMSE", "DASR", "PeakError", "PeakIdxError", "NSE"]
    source = seed_metrics[(seed_metrics.Dataset == "extreme_all") & seed_metrics.Model.isin(CROSS_NODE_MODEL_ORDER)]
    rows = []
    for node in sorted(source.Node.unique()):
        for model in CROSS_NODE_MODEL_ORDER:
            part = source[(source.Node == node) & (source.Model == model)]
            row = {"Node": node, "Model": model, "N_seeds": part.Seed.nunique()}
            for metric in metrics:
                row[f"{metric}_mean"] = part[metric].mean(); row[f"{metric}_std"] = part[metric].std()
            rows.append(row)
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    path = out/"Table3_CrossNode_Extreme_SeedSummary.csv"
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig"); return path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-metrics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    outputs = build_publication_tables(pd.read_csv(args.seed_metrics), args.output)
    for name, path in outputs.items():
        print(f"{name}: {path}")


if __name__ == "__main__":
    main()
