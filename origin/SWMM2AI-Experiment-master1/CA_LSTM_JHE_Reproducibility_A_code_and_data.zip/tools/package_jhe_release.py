"""Create separate JHE submission and full reproducibility archives."""
from __future__ import annotations
import argparse
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

DOCS=("Manuscript_CA-LSTM_JHE_Final.docx","Manuscript_CA-LSTM_JHE_Final.pdf","Response_to_Editor_JHE_Final.docx","Response_to_Editor_JHE_Final.pdf")
EXCLUDED={".git",".venv",".artifacts",".pytest_cache","__pycache__"}

def _info(name):
    i=ZipInfo(name,date_time=(2026,9,11,0,0,0)); i.compress_type=ZIP_DEFLATED; i.external_attr=0o100644<<16; return i
def _write(path,files,generated=None):
    payload={n:p.read_bytes() for n,p in sorted(files.items())}; payload.update(generated or {})
    payload["SHA256SUMS.txt"]=("\n".join(f"{sha256(v).hexdigest()}  {n}" for n,v in sorted(payload.items()))+"\n").encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(path,"w") as z:
        for n,v in sorted(payload.items()): z.writestr(_info(n),v)
    with ZipFile(path) as z: assert z.testzip() is None

def package_jhe_release(project_root,output_dir):
    project=Path(project_root).resolve(); output=Path(output_dir).resolve(); final=project/"deliverables/jhe_final"
    submission={n:final/n for n in DOCS}
    for n,p in submission.items():
        if not p.is_file(): raise FileNotFoundError(p)
    for number in range(1,7):
        matches=list((project/"output/publication_final/figures").glob(f"Fig{number}_*.tif"))
        if len(matches)!=1: raise ValueError(f"Fig{number} TIFF count={len(matches)}")
        submission[f"figures/{matches[0].name}"]=matches[0]
    matches=list((project/"output/cross_node/figures").glob("Fig7_*.tif"))
    if len(matches)!=1: raise ValueError(f"Fig7 TIFF count={len(matches)}")
    submission[f"figures/{matches[0].name}"]=matches[0]
    submit=output/"CA_LSTM_JHE_Submission.zip"
    _write(submit,submission,{"SUBMISSION_FILE_MAP.txt":b"Upload the manuscript DOCX, response DOCX, and Fig1-Fig7 TIFF files. PDFs are reading copies.\n"})
    reproduction={}
    for path in sorted(project.rglob("*")):
        if not path.is_file(): continue
        rel=path.relative_to(project)
        if any(x in EXCLUDED for x in rel.parts) or path.suffix.lower() in {".pyc",".zip"}: continue
        try: path.resolve().relative_to(output)
        except ValueError: pass
        else: continue
        reproduction[rel.as_posix()]=path
    repro=output/"CA_LSTM_JHE_Reproducibility.zip"; _write(repro,reproduction); return submit,repro

def main():
    p=argparse.ArgumentParser(); p.add_argument("--project-root",default="."); p.add_argument("--output",required=True); a=p.parse_args()
    for path in package_jhe_release(a.project_root,a.output): print(path)
if __name__=="__main__": main()
