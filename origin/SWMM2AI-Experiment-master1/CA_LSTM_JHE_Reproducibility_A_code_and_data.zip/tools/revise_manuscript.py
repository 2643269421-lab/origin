"""Create the clean revised manuscript and point-by-point editor response."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parents[3] / "upload" / "Manuscript(2).docx"
FINAL = ROOT / "deliverables"
RESULTS = ROOT / "output" / "publication_final"


PARAGRAPH_REPLACEMENTS = {
    0: "Hydrologically Consistent Causal-Attention Surrogates for SWMM under Extreme and Observed Rainfall",
    8: (
        "Urban stormwater simulation is central to flood forecasting and drainage-system operation, but repeated "
        "Storm Water Management Model (SWMM) runs can impede ensemble and optimization workflows. This study asks a "
        "hydrologically focused question: does enforcing temporal non-anticipation in a recurrent surrogate improve "
        "transfer from ordinary design storms to more extreme rainfall? Seven models were evaluated in a paired "
        "ablation study using a 200-event synthetic development pool, four independent extreme sets (T = 20, 30, 50, "
        "and 100 years; 15 events each), 97 complete independently observed rainfall–level records, and 10 fixed random "
        "seeds. All data transformations were fitted on each seed's training partition only. Across the four extreme "
        "sets, causal-attention LSTM (CA-LSTM) reduced RMSE by 31.7% relative to LSTM and increased the Direction "
        "Alignment Success Rate (DASR) by 24.7 percentage points; both paired differences remained significant after "
        "Holm correction (adjusted p = 0.0098). A random-order prefix control achieved statistically indistinguishable "
        "RMSE from CA-LSTM (adjusted p = 1.000) but 12.7 percentage points lower DASR (adjusted p = 0.0098), indicating "
        "that chronological ordering primarily improves hydrograph-direction consistency rather than every accuracy "
        "measure. Adding smoothness and peak-time regularization did not provide a robust additional benefit. On the 97 "
        "observed events, RandomMaskLSTM had the highest DASR (53.1%), whereas causal variants reduced mean peak-timing "
        "error relative to LSTM. The results support temporal non-anticipation as a useful architectural prior while "
        "also delimiting its scope: it is not a substitute for hydraulic conservation equations, calibration, or "
        "cross-network validation."
    ),
    10: (
        "Operational drainage studies often require many SWMM evaluations for uncertainty analysis, scenario screening, "
        "or control optimization. The experiments show that a surrogate should be judged on hydrograph shape and timing, "
        "not only average error. Enforcing temporal non-anticipation improved extreme-event direction consistency across "
        "10 paired training seeds, but it did not dominate every metric on independently observed records. Accordingly, "
        "practitioners should treat causal attention as one auditable model-design choice, retain a noncausal mask control, "
        "and verify magnitude, timing, and physical feasibility on locally calibrated observations before deployment."
    ),
    12: (
        "Keywords: SWMM surrogate modeling; Urban drainage hydrology; Causal attention; Extreme rainfall; "
        "Hydrograph timing; Ablation study"
    ),
    15: (
        "Urban drainage planning and operation rely on hydrologic–hydraulic simulators such as the U.S. EPA Storm Water "
        "Management Model (SWMM) (Rossman and Simon 2022). Dynamic-wave routing resolves rapidly varying conduit and node "
        "states, but the computational burden is multiplied when a model must be called repeatedly for ensemble forecasts, "
        "control optimization, or uncertainty analysis. Surrogate models have therefore been coupled with urban flood and "
        "drainage workflows to accelerate forecasting and operations (Leitão et al. 2010; Li et al. 2022; Xu et al. 2024; "
        "Li et al. 2026)."
    ),
    16: (
        "Recurrent networks can emulate rainfall–runoff and drainage responses when training and application conditions "
        "are similar (Kratzert et al. 2018; Xiang et al. 2020). The harder engineering problem is extrapolation beyond the "
        "training rainfall envelope. Under high-intensity storms, small hydrograph timing or trend errors can alter the "
        "estimated onset and duration of critical depth, even when aggregate RMSE appears acceptable (Frame et al. 2022). "
        "A useful SWMM surrogate should therefore preserve the non-anticipatory rainfall-to-depth response and be assessed "
        "with magnitude, direction, and peak-timing metrics."
    ),
    17: (
        "Scientific knowledge can enter a surrogate through the architecture or the objective function. Physics-guided "
        "urban-flood models have shown the value of connecting data-driven prediction with simulator-derived information "
        "(Madayala et al. 2022). In the present sequence-to-sequence setting, an architecture-level causal mask prevents a "
        "prediction at time t from using hidden states at later times. This is a temporal non-anticipation constraint, not "
        "a discretization of the Saint-Venant equations. At the loss level, smoothness and peak-time penalties can encourage "
        "hydrologically plausible shapes, but they likewise do not enforce mass or momentum conservation. Distinguishing "
        "these levels avoids overstating the physical content of either method."
    ),
    18: (
        "Attribution requires a controlled experiment. A masked model may improve because it uses chronological order, "
        "because it sees fewer positions, or because masking regularizes optimization. Published comparisons often vary "
        "training data, hyperparameters, and initialization simultaneously. We therefore use identical event pools, "
        "train-only scaling, model capacity, optimization settings, and 10 paired seeds, together with a random-order "
        "prefix control that exposes the same number of positions as the causal model at every time step."
    ),
    19: (
        "This study contributes (1) an auditable SWMM-to-surrogate workflow with cached simulator outputs and explicit data "
        "provenance; (2) a seven-model ablation that separates unmasked attention, random-order masking, chronological causal "
        "masking, and two temporal regularizers; and (3) paired seed-level inference with Holm correction across prespecified "
        "comparisons. The emphasis is the hydrologic interpretation of the resulting hydrographs rather than proposing "
        "causal attention as a complete physics model."
    ),
    20: (
        "Three research questions organize the analysis. RQ1: Does temporal non-anticipation improve extreme-rainfall "
        "magnitude and direction metrics relative to LSTM and unconstrained attention? RQ2: Does chronological order add "
        "information beyond masking alone? RQ3: Do smoothness or peak-time penalties add a reproducible benefit after the "
        "architecture already enforces non-anticipation, and how do the resulting models behave on independent observed "
        "rainfall–level records?"
    ),
    23: (
        "The supplied EPA SWMM input model represents a compact urban drainage network with 74 subcatchments (summed model "
        "area 1.799 ha), 49 junctions, 49 conduits, and one outfall. Horton infiltration and dynamic-wave flow routing are "
        "used. The routing step is 10 s, while inputs and reported outputs are sampled every 5 min over 24 h (288 steps). "
        "The surrogate target is water depth at node SN_001, whose SWMM parameters include an invert elevation of 1.46 m, "
        "maximum depth of 2.14 m, and initial depth of 0.13 m. No new field calibration is claimed in this study; the SWMM "
        "model is treated as the deterministic reference simulator for the synthetic experiments."
    ),
    25: (
        "Chicago design storms were generated at a 5-min interval using the implemented intensity–duration parameters "
        "A = 23.0904, C = 1.0116, b = 18.8619, and n = 0.8418. Event duration and peak-position coefficient were sampled "
        "from 1–6 h and 0.3–0.7, respectively, and the storm start was randomized within the 24-h window. A development pool "
        "of 200 events used return periods no greater than 10 years. For each seed, events were split 80%/10%/10% into "
        "training, validation, and held-out in-distribution partitions; rainfall and depth min–max scalers were fitted only "
        "on the 160 training events. Four out-of-distribution sets contained 15 independently generated storms each at "
        "T = 20, 30, 50, and 100 years. All 260 SWMM runs completed successfully and their arrays, metadata, and SHA-256 "
        "hashes were cached before neural-network training (Fig. 1)."
    ),
    27: (
        "Seven main-text models form a coordinated ablation. Each recurrent model uses two unidirectional layers with 64 "
        "hidden units and dropout 0.3. The input is rainfall intensity and the output is SN_001 depth at each of 288 time "
        "steps. GRU is retained as an appendix-only recurrent control."
    ),
    28: (
        "LSTM baseline. A two-layer LSTM maps the rainfall sequence to the depth sequence using a feed-forward output head; "
        "it contains no explicit attention context."
    ),
    29: (
        "AttentionLSTM. A scalar score is learned for each LSTM hidden state and normalized over the entire 288-step "
        "sequence. The resulting global context is added to every step's local prediction. Because the global context can "
        "include later hidden states, this model is an intentionally noncausal attention baseline rather than a deployable "
        "online predictor."
    ),
    30: (
        "CA-LSTM. The same recurrent representation is combined with a prefix attention context. At time t, attention "
        "weights are normalized only over hidden states 1,...,t, so predictions cannot use future rainfall-derived hidden "
        "states. Cumulative weighted sums evaluate all prefixes in linear time. The constraint expresses temporal "
        "non-anticipation; it does not encode conduit topology or the dynamic-wave equations."
    ),
    31: (
        "Temporally regularized causal models. PCCA-LSTM retains the CA-LSTM architecture and replaces plain MSE with a "
        "composite objective (Eq. 1):"
    ),
    33: "where the curvature penalty is",
    35: "and the differentiable peak-time penalty is",
    37: (
        "with λ_s = 0.01, λ_p = 0.05, and soft-argmax temperature τ = 0.1. These are temporal-shape "
        "regularizers, not governing-equation residuals."
    ),
    38: (
        "RandomMaskLSTM. A fixed random permutation destroys chronological order while matching CA-LSTM's visibility "
        "count: at query step t, the first t + 1 positions in that permutation are visible. The recurrent backbone, "
        "attention scorer, and output head otherwise match CA-LSTM. This control separates chronological ordering from the "
        "effect of progressively exposing more positions."
    ),
    39: (
        "Loss ablations. CA+SmoothLoss uses only the curvature penalty (λ_s = 0.01), CA+PeakTimeLoss uses only the soft "
        "peak-time penalty (λ_p = 0.05), and PCCA-LSTM uses both."
    ),
    41: (
        "All models were trained for at most 100 epochs with batch size 32, Adam learning rate 0.001, and early-stopping "
        "patience 15. The fixed seeds were 42, 123, 456, 789, 1024, 2048, 3072, 4096, 5120, and 6144. A checkpoint was "
        "reused only when its configuration fingerprint matched the model definition, split indices, fitted scalers, input "
        "arrays, and relevant source files. The seven primary models yielded 70 checkpoints; the appendix GRU added 10."
    ),
    42: (
        "Experiments were executed on CPU using deterministic PyTorch settings. Runtime acceleration is not benchmarked "
        "here because a defensible speed comparison requires matched hardware, warm-up, batch size, and SWMM invocation "
        "conditions. The reproducibility package instead records software dependencies, raw-event hashes, checkpoint "
        "metadata, and complete training histories."
    ),
    43: (
        "Synthetic-event metrics were RMSE (m), Nash–Sutcliffe efficiency (NSE), peak-depth bias (m), absolute peak-timing "
        "error (5-min steps), and DASR. DASR is the percentage of steps for which the sign of predicted depth change matches "
        "the simulated change, excluding numerically negligible target changes. The prespecified inferential analysis used "
        "two-sided Wilcoxon signed-rank tests on 10 paired seed means pooled over T = 20–100, followed by Holm adjustment "
        "within each metric's five comparisons. Observed workbooks were included only when both named columns contained "
        "288 paired numeric rows; no incomplete record was interpolated."
    ),
    46: (
        "Table 1 reports seed-level mean ± standard deviation for the 15 T = 100 events. Across all four extreme return "
        "periods, performance degraded gradually with rainfall severity (Fig. 2), while the relative architecture patterns "
        "were stable enough for paired seed analysis."
    ),
    47: (
        "At T = 100, CA-LSTM obtained RMSE 0.0082 ± 0.0007 m, DASR 71.1 ± 2.4%, and NSE 0.9877 ± 0.0019, compared with "
        "0.0117 ± 0.0023 m, 45.6 ± 6.6%, and 0.9745 ± 0.0104 for LSTM. When seed means were pooled across T = 20–100, "
        "CA-LSTM reduced RMSE from 0.01044 to 0.00713 m (31.7%) and increased DASR from 45.2% to 69.9% (+24.7 percentage "
        "points). Both paired comparisons remained significant after Holm adjustment (adjusted p = 0.0098; Fig. 4)."
    ),
    49: (
        "Unconstrained AttentionLSTM reduced pooled extreme RMSE only descriptively (0.00979 versus 0.01044 m; adjusted "
        "p = 1.000) but improved DASR by 11.4 percentage points (adjusted p = 0.0195). Thus, added temporal context can "
        "improve hydrograph direction without reliably improving magnitude error. CA-LSTM produced the highest DASR among "
        "the seven primary models across the pooled extreme sets (Fig. 3)."
    ),
    51: (
        "RandomMaskLSTM had pooled extreme RMSE 0.00698 m, slightly below CA-LSTM's 0.00713 m; the paired difference was "
        "not significant (adjusted p = 1.000). In contrast, RandomMaskLSTM DASR was 57.2%, 12.7 percentage points below "
        "CA-LSTM (adjusted p = 0.0098). Random masking also improved both RMSE and DASR over LSTM (adjusted p = 0.0156 and "
        "0.0098, respectively). Consequently, the data do not support claiming that causal order uniquely improves every "
        "accuracy metric; they do support a specific contribution to direction consistency beyond masking alone."
    ),
    53: (
        "Relative to CA-LSTM, pooled extreme RMSE increased to 0.00725 m with SmoothLoss, 0.00756 m with PeakTimeLoss, and "
        "0.00758 m with both penalties (Fig. 5). The prespecified PCCA-LSTM versus CA-LSTM test yielded raw p = 0.0273 but "
        "did not remain significant after Holm correction (adjusted p = 0.0820). Their DASR difference was also not "
        "significant (adjusted p = 0.4316). The defensible conclusion is therefore absence of a robust added benefit under "
        "the tested weights, not proof that temporal regularization is generally harmful."
    ),
    54: (
        "The descriptive pattern is hydrologically plausible: the target node responds within approximately one 5-min "
        "report interval of the rainfall peak, so a curvature penalty may suppress legitimate rapid changes, while a "
        "global peak-time penalty may offer little guidance after chronological information flow is already enforced. "
        "This explanation is a mechanism hypothesis that requires testing with additional networks and penalty weights."
    ),
    55: (
        "Seed-level variability was modest for all causal variants. On T = 100, RMSE standard deviations ranged from "
        "0.00068 m for CA-LSTM to 0.00085 m for PCCA-LSTM. The similar dispersion and nonsignificant adjusted contrast do "
        "not support the earlier interpretation that regularized models were broadly unstable."
    ),
    57: (
        "The observed archive contained 100 workbooks from 2023–2025. Ninety-seven contained exactly 288 paired numeric "
        "values in the explicit rainfall and level columns. Records dated 2024-10-06, 2024-06-30, and 2024-07-12 contained "
        "201, 216, and 287 valid pairs, respectively, and were excluded without interpolation. Table 2 therefore summarizes "
        "970 evaluations per model (10 seeds × 97 events). Absolute observed levels use a sensor datum that is not aligned "
        "with SWMM relative depth; observed RMSE and NSE are consequently not interpreted."
    ),
    58: (
        "RandomMaskLSTM produced the highest observed DASR (53.08 ± 0.19%), followed by CA-LSTM (52.20 ± 0.21%) and the "
        "three causal loss variants (52.09–52.15%). LSTM reached 44.65 ± 1.68%. Causal variants did, however, reduce mean "
        "absolute peak-timing error: 36.43 ± 4.85 steps for CA-LSTM and 35.57 ± 5.04 for CA+PeakTimeLoss, compared with "
        "49.36 ± 1.35 for LSTM (Fig. 6). Because no observed-event hypothesis test was prespecified, these contrasts are "
        "reported descriptively."
    ),
    61: (
        "The simulator diagnostics give the architectural result a hydraulic interpretation. Across the synthetic training "
        "and extreme sets, the SN_001 depth peak occurred within −5 to +5 min of the rainfall peak; at T = 100, lags were "
        "0–5 min. The 5-min report interval and coincident peaks indicate a fast local response at this target. A prefix "
        "context prevents any predicted state from using later rainfall-derived states, while the random-order control "
        "retains the same context size without the time arrow. The significant DASR gap between these controls is therefore "
        "consistent with, but does not alone prove, a benefit from chronological organization."
    ),
    63: (
        "The loss terms encode generic shape preferences rather than the continuity or momentum equations. A second-"
        "difference penalty can conflict with sharp modeled responses, and a single soft peak summarizes only one aspect "
        "of a hydrograph. Their lack of robust improvement is thus specific to this target, event generator, and fixed "
        "weights. Future comparisons should include weight sweeps, event-adaptive penalties, water-balance residuals, and "
        "network-topology constraints before drawing general conclusions about physics-guided learning."
    ),
    65: (
        "The observed results reveal a different ordering from the synthetic extremes: RandomMaskLSTM slightly exceeded "
        "CA-LSTM in DASR, whereas causal variants showed lower peak-timing error. This metric dependence is expected because "
        "the observed records differ from the synthetic Chicago storms and are not datum-aligned to the SWMM depth target. "
        "The external evaluation therefore tests transfer of temporal shape only; it is not a calibrated field validation "
        "of water-level magnitude. This distinction should guide operational interpretation."
    ),
    67: (
        "This study compared architecture-level temporal non-anticipation with loss-level temporal-shape regularization in "
        "SWMM surrogates using seven primary models, 10 paired seeds, four extreme return periods, and 97 complete observed "
        "events. Three conclusions follow."
    ),
    68: (
        "First, CA-LSTM improved pooled extreme RMSE by 31.7% and DASR by 24.7 percentage points relative to LSTM; both "
        "effects survived Holm correction. The random-order prefix control matched CA-LSTM on RMSE but was significantly "
        "worse on DASR, so chronological order contributed specifically to hydrograph-direction consistency rather than "
        "universal predictive dominance."
    ),
    69: (
        "Second, smoothness and peak-time penalties did not add a statistically robust benefit to the causal architecture "
        "under the tested weights. Because these objectives are shape regularizers rather than governing-equation residuals, "
        "the result should not be generalized to all physics-guided learning."
    ),
    70: (
        "Third, observed-event ranking depended on the metric: RandomMaskLSTM had the highest DASR, whereas causal variants "
        "reduced peak-timing error relative to LSTM. This demonstrates why SWMM surrogates should be evaluated with multiple "
        "hydrologically interpretable endpoints and with clear separation between simulator emulation and field validation."
    ),
    71: (
        "Limitations are the single network and target node, Chicago-only synthetic forcing, fixed regularization weights, "
        "10 seeds, and the absence of datum-aligned observed depth for magnitude validation. Temporal causal attention does "
        "not enforce mass conservation, conduit connectivity, or dynamic-wave equations. Future work should calibrate and "
        "align field observations, test multiple nodes and networks, diversify storm structures, and compare temporal masks "
        "with topology-aware and conservation-residual architectures."
    ),
    78: (
        "A two-layer GRU with 64 hidden units was trained under the same 10 seeds as an appendix control. At T = 100, its "
        "RMSE was 0.0097 ± 0.0009 m and DASR was 56.6 ± 9.9%; on the 97 observed events, DASR was 47.6 ± 1.6%. These values "
        "place GRU between the plain LSTM and the strongest causal-direction results, and they do not alter the main "
        "ablation interpretation."
    ),
    80: (
        "The source code, experiment configuration, trained checkpoints, cached synthetic events, complete metric files, "
        "data-exclusion audit, tables, and figures supporting this study are provided in the accompanying reproducibility "
        "archive and at https://github.com/2643269421-lab/origin/tree/main/origin/SWMM2AI-Experiment-master1. Observed "
        "workbooks are included only subject to the original data-sharing permissions."
    ),
    84: (
        "The accompanying archive contains the code, software environment specification, cached SWMM events with SHA-256 "
        "manifest, training histories and checkpoints, event- and seed-level metrics, observed-data audit, manuscript tables, "
        "and six submission-ready TIFF figures."
    ),
    110: (
        "Table 1. Seed-Level Performance on T = 100-Year Synthetic Rainfall (Mean ± Standard Deviation across 10 Seeds; "
        "15 Events per Seed)"
    ),
    112: (
        "Table 2. Shape-Based Generalization on 97 Complete Observed Events (Mean ± Standard Deviation across 10 Seeds; "
        "970 Evaluations per Model)"
    ),
    115: "Fig. 1. Leakage-free experimental framework and evidence flow.",
    116: "Fig. 2. Model performance across extreme rainfall return periods.",
    117: "Fig. 3. Overall RMSE comparison for the seven main-text models.",
    118: "Fig. 4. Paired-seed comparison of LSTM and CA-LSTM.",
}


NEW_REFERENCES = [
    (
        "Li, X., Hou, J., Chai, J., Du, Y., Han, H., Fan, C., and Qiao, M. 2022. "
        '"Multisurrogate assisted evolutionary algorithm–based optimal operation of drainage facilities in urban storm '
        'drainage systems for flood mitigation." J. Hydrol. Eng., 27(11): 04022025. '
        "https://doi.org/10.1061/(ASCE)HE.1943-5584.0002214."
    ),
    (
        "Li, J., Xu, Z., and Hu, D. 2026. "
        '"Deep learning–based multiobjective optimization framework for stormwater management models." '
        "J. Hydrol. Eng., 31(3). https://doi.org/10.1061/JHYEFF.HEENG-6784."
    ),
    (
        "Madayala, A. B., Jain, A., and Lohani, B. 2022. "
        '"Development of a physics-guided neural network model for effective urban flood management." '
        "J. Hydrol. Eng., 27(9): 04022017. https://doi.org/10.1061/(ASCE)HE.1943-5584.0002196."
    ),
]


def set_cell_text(cell, text: str) -> None:
    cell.text = text
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.font.name = "Times New Roman"
            run.font.size = Pt(9)


def set_column_widths(table, widths: list[float]) -> None:
    table.autofit = False
    for row in table.rows:
        for cell, width in zip(row.cells, widths):
            cell.width = Inches(width)
            tc_width = cell._tc.get_or_add_tcPr().first_child_found_in("w:tcW")
            if tc_width is not None:
                tc_width.set(qn("w:w"), str(int(width * 1440)))
                tc_width.set(qn("w:type"), "dxa")


def fmt_pm(mean: float, std: float, digits: int) -> str:
    return f"{mean:.{digits}f} ± {std:.{digits}f}"


def append_after(paragraph, text: str):
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = paragraph._parent.add_paragraph()
    new_para._p.getparent().remove(new_para._p)
    new_p.getparent().replace(new_p, new_para._p)
    new_para.style = paragraph.style
    new_para.add_run(text)
    return new_para


def add_hyperlink(paragraph, text: str, url: str) -> None:
    part = paragraph.part
    relationship_id = part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), relationship_id)
    run = OxmlElement("w:r")
    run_properties = OxmlElement("w:rPr")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), "0563C1")
    underline = OxmlElement("w:u")
    underline.set(qn("w:val"), "single")
    run_properties.append(color)
    run_properties.append(underline)
    run.append(run_properties)
    text_node = OxmlElement("w:t")
    text_node.text = text
    run.append(text_node)
    hyperlink.append(run)
    paragraph._p.append(hyperlink)


def revise_manuscript() -> Path:
    doc = Document(SOURCE)
    for index, text in PARAGRAPH_REPLACEMENTS.items():
        doc.paragraphs[index].text = text

    li_2019 = next(p for p in doc.paragraphs if p.text.startswith("Li, S., Jin, X."))
    paragraph = li_2019.insert_paragraph_before(NEW_REFERENCES[1])
    paragraph.style = doc.paragraphs[87].style
    lim = next(p for p in doc.paragraphs if p.text.startswith("Lim, B."))
    paragraph = lim.insert_paragraph_before(NEW_REFERENCES[0])
    paragraph.style = doc.paragraphs[87].style
    palmitessa = next(p for p in doc.paragraphs if p.text.startswith("Palmitessa, R."))
    paragraph = palmitessa.insert_paragraph_before(NEW_REFERENCES[2])
    paragraph.style = doc.paragraphs[87].style

    fig4 = next(p for p in doc.paragraphs if p.text.startswith("Fig. 4."))
    fig5 = append_after(fig4, "Fig. 5. Loss-regularization ablation within the causal architecture.")
    append_after(fig5, "Fig. 6. Performance on complete independently observed rainfall events.")

    extreme = pd.read_csv(
        RESULTS / "tables" / "Table1_Extreme_T100_SeedSummary.csv",
        encoding="utf-8-sig",
    ).set_index("Model")
    observed = pd.read_csv(
        RESULTS / "tables" / "Table2_Observed_SeedSummary.csv",
        encoding="utf-8-sig",
    ).set_index("Model")
    model_order = list(extreme.index)

    table1 = doc.tables[0]
    headers1 = [
        "Model", "RMSE (m)", "DASR (%)", "Peak bias (m)",
        "Peak-step error", "NSE", "N seeds",
    ]
    for cell, text in zip(table1.rows[0].cells, headers1):
        set_cell_text(cell, text)
    for row, model in zip(table1.rows[1:], model_order):
        values = extreme.loc[model]
        texts = [
            model,
            fmt_pm(values.RMSE_mean, values.RMSE_std, 4),
            fmt_pm(values.DASR_mean, values.DASR_std, 1),
            fmt_pm(values.PeakError_mean, values.PeakError_std, 4),
            fmt_pm(values.PeakIdxError_mean, values.PeakIdxError_std, 2),
            fmt_pm(values.NSE_mean, values.NSE_std, 4),
            str(int(values.N_seeds)),
        ]
        for cell, text in zip(row.cells, texts):
            set_cell_text(cell, text)
    set_column_widths(table1, [1.35, 1.05, 0.85, 1.10, 0.95, 1.05, 0.55])

    table2 = doc.tables[1]
    headers2 = ["Model", "DASR (%)", "Peak-step error", "N seeds"]
    for cell, text in zip(table2.rows[0].cells, headers2):
        set_cell_text(cell, text)
    for row, model in zip(table2.rows[1:], model_order):
        values = observed.loc[model]
        texts = [
            model,
            fmt_pm(values.DASR_mean, values.DASR_std, 2),
            fmt_pm(values.PeakIdxError_mean, values.PeakIdxError_std, 2),
            str(int(values.N_seeds)),
        ]
        for cell, text in zip(row.cells, texts):
            set_cell_text(cell, text)
    set_column_widths(table2, [1.65, 1.25, 2.05, 0.70])

    doc.core_properties.title = PARAGRAPH_REPLACEMENTS[0]
    doc.core_properties.subject = "Revised manuscript emphasizing SWMM hydrology and hydraulic interpretation"
    doc.core_properties.comments = "Clean revision generated from the paired 10-seed publication experiment."

    for paragraph in doc.paragraphs:
        for run in paragraph.runs:
            if not run.font.name:
                run.font.name = "Times New Roman"

    FINAL.mkdir(parents=True, exist_ok=True)
    path = FINAL / "Manuscript_CA-LSTM_Revised.docx"
    doc.save(path)
    return path


def set_doc_defaults(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)
    normal.paragraph_format.line_spacing = 2
    normal.paragraph_format.space_after = Pt(0)
    for name in ("Title", "Heading 1", "Heading 2"):
        style = doc.styles[name]
        style.font.name = "Times New Roman"
        style.font.color.rgb = RGBColor(0, 0, 0)


def response_paragraph(doc: Document, label: str, body: str) -> None:
    paragraph = doc.add_paragraph()
    paragraph.add_run(label).bold = True
    paragraph.add_run(body)


def create_response() -> Path:
    doc = Document()
    set_doc_defaults(doc)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Response to the Editor's Initial Assessment")
    run.bold = True
    run.font.size = Pt(16)
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run(PARAGRAPH_REPLACEMENTS[0]).italic = True

    doc.add_paragraph(
        "Dear Editor,\n\nThank you for the initial assessment and for inviting a substantially revised new "
        "submission. We have reoriented the manuscript from a machine-learning-method comparison toward the "
        "hydrologic and hydraulic question of whether temporal non-anticipation improves SWMM hydrograph emulation "
        "under extreme rainfall. We also repeated the full experiment with leakage-free preprocessing, 10 paired seeds, "
        "explicit observed-data auditing, and multiplicity-adjusted statistical tests. The principal changes and direct "
        "responses are provided below."
    )

    doc.add_heading("Comment 1", level=1)
    response_paragraph(
        doc,
        "Editor's comment: ",
        "The work is too specific to deep-learning details and gives insufficient attention to the physics of the problem, "
        "as reflected in the terminology."
    )
    response_paragraph(
        doc,
        "Response: ",
        "We agree that the earlier version overemphasized machine-learning jargon and overstated the physical status of "
        "the proposed constraints. The revised title, abstract, introduction, methods, discussion, and conclusions now "
        "center the SWMM rainfall-to-depth problem. The SWMM configuration is reported explicitly: 74 subcatchments, 49 "
        "junctions, 49 conduits, one outfall, Horton infiltration, dynamic-wave routing, a 10-s routing step, a 5-min report "
        "step, and depth at node SN_001 as the surrogate target. We also added simulator-derived response-lag diagnostics, "
        "NSE, peak-depth bias, peak-timing error, and direction consistency."
    )
    response_paragraph(
        doc,
        "Terminology correction: ",
        "The manuscript now calls causal attention a temporal non-anticipation constraint and calls the smoothness and "
        "peak-time terms temporal-shape regularizers. It states explicitly that neither device enforces mass conservation, "
        "momentum conservation, conduit topology, or the Saint-Venant equations. Claims of a universal 'physical prior' "
        "have been removed."
    )
    response_paragraph(
        doc,
        "Hydrologic interpretation: ",
        "The revised discussion connects the result to the fast response of the modeled target node. Across synthetic "
        "events, the depth peak occurs within one 5-min report interval of the rainfall peak. The chronological mask is "
        "therefore interpreted narrowly as preventing nonphysical access to future rainfall-derived states, not as a "
        "replacement for the hydraulic model."
    )

    doc.add_heading("Comment 2", level=1)
    response_paragraph(
        doc,
        "Editor's comment: ",
        "The paper was not related sufficiently to papers published in hydraulic or hydrologic engineering."
    )
    response_paragraph(
        doc,
        "Response: ",
        "The literature review now situates the study within urban-flood physics-guided modeling and surrogate-assisted "
        "storm-drainage operation. We added and discussed work from the Journal of Hydrologic Engineering, including "
        "Madayala et al. (2022) on physics-guided urban-flood modeling, Li et al. (2022) on multisurrogate drainage-facility "
        "operation, and Li et al. (2026) on deep-learning-assisted SWMM optimization. The practical motivation is now "
        "repeated SWMM evaluation for forecasting, scenario screening, and control rather than deep learning in isolation."
    )

    doc.add_heading("Additional Reproducibility and Integrity Revisions", level=1)
    changes = [
        "Regenerated 200 development events and 60 independent extreme events (15 each at T = 20, 30, 50, and 100 years); all 260 SWMM simulations completed successfully and were cached with SHA-256 provenance.",
        "Used a seed-specific 80%/10%/10% event split and fitted rainfall and depth scalers only on the training partition, eliminating preprocessing leakage.",
        "Trained seven primary models for 10 fixed seeds under identical settings, with a GRU control in the appendix (80 total checkpoints).",
        "Replaced the former random mask with a fixed random-order prefix control that matches the causal model's visibility count at every time step while destroying chronological order.",
        "Audited all 100 observed workbooks. Ninety-seven complete 288-row events were included; three incomplete files were excluded without interpolation and listed in a machine-readable audit.",
        "Performed paired Wilcoxon tests on seed means and applied Holm correction within each metric's five prespecified comparisons.",
        "Corrected unsupported site, calibration, hardware, and runtime statements. The revised manuscript does not claim field calibration or a speed-up that was not benchmarked under controlled conditions.",
        "Replaced all numerical results, tables, and figures with outputs generated by the archived code. Figure file names and internal figure headings now use the same numbering and descriptive wording."
    ]
    for item in changes:
        paragraph = doc.add_paragraph(item, style="List Bullet")
        paragraph.paragraph_format.line_spacing = 1.5
        paragraph.paragraph_format.space_after = Pt(6)

    doc.add_heading("Revised Main Findings", level=1)
    doc.add_paragraph(
        "Across T = 20–100, CA-LSTM reduced RMSE by 31.7% and increased DASR by 24.7 percentage points relative to "
        "LSTM; both contrasts remained significant after Holm correction (adjusted p = 0.0098). RandomMaskLSTM and "
        "CA-LSTM were statistically indistinguishable in RMSE (adjusted p = 1.000), but CA-LSTM exceeded the random "
        "control by 12.7 percentage points in DASR (adjusted p = 0.0098). The combined loss regularization did not "
        "significantly differ from CA-LSTM after correction (RMSE adjusted p = 0.0820). On observed events, the random "
        "control had the highest DASR, while causal variants reduced peak-timing error. We have revised the claims to "
        "reflect this metric-dependent evidence rather than presenting causal attention as uniformly superior."
    )

    doc.add_paragraph(
        "We appreciate the assessment, which led to a more hydraulically grounded, transparent, and reproducible paper. "
        "We hope the revised manuscript is now suitable for evaluation as a new submission.\n\nSincerely,\nThe Authors"
    )

    FINAL.mkdir(parents=True, exist_ok=True)
    path = FINAL / "Response_to_Editor.docx"
    doc.save(path)
    return path


if __name__ == "__main__":
    print(revise_manuscript())
    print(create_response())
