"""Create the evidence-linked Journal of Hydrologic Engineering revision."""

from __future__ import annotations
import argparse
from copy import deepcopy
from pathlib import Path
import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

TITLE = "Node-Dependent Effects of Temporal Causal Attention in SWMM Surrogates under Extreme and Observed Rainfall"


def _exact(doc, text): return next(p for p in doc.paragraphs if p.text.strip() == text)
def _start(doc, text): return next(p for p in doc.paragraphs if p.text.strip().startswith(text))
def _after(doc, label):
    paragraphs=doc.paragraphs; return paragraphs[next(i for i,p in enumerate(paragraphs) if p.text.strip()==label)+1]
def _set(p,text):
    p.text=text
    for r in p.runs:
        r.font.name="Times New Roman"; r._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"),"Times New Roman")
def _black(p):
    for r in p.runs: r.font.color.rgb=RGBColor(0,0,0)
def _fmt(m,s,d): return f"{m:.{d}f} ± {s:.{d}f}"


def _numbers(evidence):
    summary=pd.read_csv(evidence/"tables/Table3_CrossNode_Extreme_SeedSummary.csv")
    tests=pd.read_csv(evidence/"evaluation/cross_node_paired_tests.csv")
    def s(node,model): return summary[(summary.Node==node)&(summary.Model==model)].iloc[0]
    def t(node,metric,second): return tests[(tests.Node==node)&(tests.metric==metric)&(tests.second_model==second)].iloc[0]
    return summary,s,t


def _cell(cell,text):
    cell.text=str(text)
    for p in cell.paragraphs:
        for r in p.runs: r.font.name="Times New Roman"; r.font.size=Pt(8)


def _add_table3(doc,summary):
    heading=_exact(doc,"Figure Caption List")
    caption=heading.insert_paragraph_before("Table 3. Cross-Node Performance under Pooled Extreme Rainfall (Mean ± Standard Deviation across 10 Paired Seeds)")
    table=doc.add_table(rows=1,cols=7); props=deepcopy(doc.tables[0]._tbl.tblPr)
    table._tbl.remove(table._tbl.tblPr); table._tbl.insert(0,props); table.autofit=False
    headers=["Node","Model","RMSE (m)","DASR (%)","Peak bias (m)","Peak-step error","NSE"]
    for c,v in zip(table.rows[0].cells,headers): _cell(c,v)
    for _,v in summary.iterrows():
        values=[v.Node,v.Model,_fmt(v.RMSE_mean,v.RMSE_std,5),_fmt(v.DASR_mean,v.DASR_std,1),
                _fmt(v.PeakError_mean,v.PeakError_std,5),_fmt(v.PeakIdxError_mean,v.PeakIdxError_std,2),_fmt(v.NSE_mean,v.NSE_std,3)]
        for c,x in zip(table.add_row().cells,values): _cell(c,x)
    widths=[.62,1.35,1,.78,1,.85,.8]
    for row in table.rows:
        for c,w in zip(row.cells,widths): c.width=Inches(w)
    heading._p.addprevious(table._tbl); caption.paragraph_format.keep_with_next=True


def revise_manuscript(source,evidence,output):
    doc=Document(source); summary,s,t=_numbers(evidence)
    m32_l,m32_c,m32_r=s("SN_032","LSTM"),s("SN_032","CA-LSTM"),s("SN_032","RandomMaskLSTM")
    m44_l,m44_c,m44_r=s("SN_044","LSTM"),s("SN_044","CA-LSTM"),s("SN_044","RandomMaskLSTM")
    p32d_l,p32d_r=t("SN_032","DASR","LSTM"),t("SN_032","DASR","RandomMaskLSTM")
    p32r=t("SN_032","RMSE","LSTM"); p44r=t("SN_044","RMSE","LSTM")
    p44d_l,p44d_r=t("SN_044","DASR","LSTM"),t("SN_044","DASR","RandomMaskLSTM")
    reduction=(m44_l.RMSE_mean-m44_c.RMSE_mean)/m44_l.RMSE_mean*100
    _set(doc.paragraphs[0],TITLE)
    _set(_after(doc,"Abstract:"),
         f"Repeated Storm Water Management Model (SWMM) evaluations can limit ensemble and optimization workflows, but a surrogate that performs well at one junction may not transfer across a drainage network. This study evaluates whether temporal non-anticipation in a recurrent surrogate has consistent effects across node locations. A seven-model, 10-seed ablation was retained at outlet-adjacent node SN_001 using 200 development storms, four independent extreme sets (T = 20, 30, 50, and 100 years; 15 events each), and 97 complete observed rainfall-level records. A topology and hydraulic audit selected mid-network node SN_032 and upstream node SN_044 before additional training. The identical 260 rainfall events were replayed through SWMM at each node, and LSTM, random-order prefix attention, and causal-attention LSTM (CA-LSTM) were trained with the same 10 paired seeds and train-only scaling. At SN_001, CA-LSTM reduced pooled extreme RMSE by 31.7% and increased direction alignment by 24.7 percentage points relative to LSTM. At SN_032, CA-LSTM did not improve RMSE significantly but increased direction alignment by {m32_c.DASR_mean-m32_l.DASR_mean:.1f} points versus LSTM and {m32_c.DASR_mean-m32_r.DASR_mean:.1f} points versus the random-order control (Holm-adjusted p = {p32d_l.p_value_holm:.4f} for both). At SN_044, CA-LSTM reduced RMSE by {reduction:.1f}% versus LSTM (adjusted p = {p44r.p_value_holm:.4f}) but had lower direction alignment than both comparators. The effects were node and metric dependent; temporal causal attention is an auditable non-anticipation device, not a universal hydraulic constraint.")
    _set(_after(doc,"Practical Applications:"),"SWMM surrogates used for scenario screening or control should be validated at the actual decision nodes. In this network, temporal causal attention improved different endpoints at different locations and reduced direction consistency at the compact upstream node. Practitioners should prespecify hydraulic targets, use multiple hydrograph metrics, and retain SWMM checks for consequential decisions.")
    _set(_start(doc,"Keywords:"),"Keywords: SWMM surrogate modeling; Urban drainage hydrology; Temporal non-anticipation; Cross-node robustness; Extreme rainfall")
    _set(_start(doc,"This study contributes"),"This study contributes (1) an auditable, leakage-free SWMM-to-surrogate workflow; (2) a controlled architecture and loss ablation at SN_001; (3) a topology-prespecified cross-node experiment at SN_032 and SN_044 using identical rainfall; and (4) paired seed-level inference that exposes node-by-metric reversals rather than assuming universal superiority.")
    _set(_start(doc,"Three research questions"),"Four research questions organize the analysis. RQ1: Does temporal non-anticipation improve extreme-rainfall magnitude and direction metrics at SN_001? RQ2: Does chronological order contribute beyond reduced visibility? RQ3: Do temporal-shape loss terms add robust benefit? RQ4: Are architecture effects consistent at a connected mid-network junction and a longest-path upstream junction?")
    _set(_after(doc,"Study Area and SWMM Model"),"The supplied EPA SWMM input model represents a compact urban drainage network with 74 subcatchments (summed model area 1.799 ha), 49 junctions, 49 conduits, and one outfall. Horton infiltration and dynamic-wave routing are used with a 10-s routing step and 5-min reporting interval. SN_001 is outlet adjacent. Before added-node training, all 49 junctions were audited using downstream path length and hops, contributing area, upstream degree, elevation, maximum depth, and downstream conduit diameter. A fixed topology-only rule selected connected mid-network node SN_032 (8 downstream conduits, 162.95 m, 0.606 ha contributing area) and longest-path upstream node SN_044 (19 conduits, 338.22 m, 0.005 ha local area, 0.32 m maximum depth, 0.15 m downstream conduit). No performance result entered node selection.")
    _set(_after(doc,"Data Generation"),"Chicago design storms were generated at 5-min intervals. The fixed experiment contains 200 development events with return periods no greater than 10 years and four independent extreme sets (T = 20, 30, 50, and 100 years; 15 events each). The same 260 rainfall sequences were replayed at SN_001, SN_032, and SN_044, giving 780 node-specific SWMM simulations. Each cache records the target node, template hash, source rainfall hash, and file digest; any failed or malformed simulation stops construction.")
    _set(_after(doc,"Model Architectures"),"Seven main-text models form the SN_001 ablation. Each recurrent model uses two unidirectional layers with 64 hidden units and dropout 0.3. The added-node experiment retains the three models needed for causal attribution—LSTM, RandomMaskLSTM, and CA-LSTM—under identical settings. RandomMaskLSTM uses a fixed random-order prefix with the same visibility count as CA-LSTM but destroys chronology.")
    _set(_after(doc,"Experimental Setup"),"All models were trained for at most 100 epochs with batch size 32, Adam learning rate 0.001, and early-stopping patience 15. Ten fixed seeds were paired across models. Scalers were fitted only to each seed's training partition. The archive contains 80 SN_001 checkpoints (seven primary models plus GRU control) and 60 added-node checkpoints, 140 total. Checkpoint fingerprints include architecture, settings, split indices, fitted scalers, source hashes, target node, and cache digest.")
    _set(_start(doc,"Synthetic-event metrics were"),"Synthetic-event metrics were RMSE (m), Nash–Sutcliffe efficiency (NSE), peak-depth bias (m), absolute peak-timing error (5-min steps), and direction alignment score (DASR). Inference uses paired Wilcoxon tests on 10 seed means. For the added-node experiment, Holm correction covers the four prespecified model contrasts within each metric, and paired rank-biserial effects are reported.")
    general=_exact(doc,"General Discussion"); heading=general.insert_paragraph_before("Cross-Node Robustness",style="Heading 2"); _black(heading)
    general.insert_paragraph_before(f"Table 3 and Fig. 7 summarize the added-node test. At SN_032, CA-LSTM obtained RMSE {m32_c.RMSE_mean:.5f} m and DASR {m32_c.DASR_mean:.1f}%, compared with {m32_l.RMSE_mean:.5f} m and {m32_l.DASR_mean:.1f}% for LSTM. The RMSE contrast was not significant (adjusted p = {p32r.p_value_holm:.4f}), whereas CA-LSTM increased DASR by {m32_c.DASR_mean-m32_l.DASR_mean:.1f} points versus LSTM and {m32_c.DASR_mean-m32_r.DASR_mean:.1f} points versus RandomMaskLSTM (adjusted p = {p32d_l.p_value_holm:.4f} for both; rank-biserial correlation = {p32d_l.rank_biserial:.1f}).")
    general.insert_paragraph_before(f"At SN_044, the metric ordering changed. CA-LSTM reduced mean RMSE from {m44_l.RMSE_mean:.5f} to {m44_c.RMSE_mean:.5f} m ({reduction:.1f}%; adjusted p = {p44r.p_value_holm:.4f}), but its DASR was {m44_c.DASR_mean:.1f}%, compared with {m44_l.DASR_mean:.1f}% for LSTM and {m44_r.DASR_mean:.1f}% for RandomMaskLSTM. Both DASR contrasts were significant after Holm correction (adjusted p = {p44d_l.p_value_holm:.4f} and {p44d_r.p_value_holm:.4f}, respectively). Thus, chronological attention did not provide spatially uniform direction consistency.")
    general.insert_paragraph_before("The upstream response helps delimit this result. SN_044 drains only 0.005 ha locally through a 0.15-m conduit and has a maximum depth of 0.32 m. The compact, partly saturated response differs from the more aggregated SN_032 and SN_001 hydrographs and plausibly changes which context organization best preserves stepwise direction; this is a mechanism interpretation, not proof of causation.")
    mechanism=_exact(doc,"Why Causal Attention Works"); _set(mechanism,"Node-Dependent Effects of Temporal Non-Anticipation"); _black(mechanism)
    _set(_after(doc,"Node-Dependent Effects of Temporal Non-Anticipation"),"The three-node evidence shows that temporal non-anticipation is neither universally beneficial nor irrelevant. It improved direction consistency at SN_001 and SN_032, but its clearest SN_044 benefit was lower RMSE, while random-order attention better preserved direction. This metric-by-node interaction is consistent with different degrees of upstream aggregation, conduit capacity, and saturation. The mask should therefore be interpreted as an information-flow constraint whose utility must be audited at the intended hydraulic target.")
    _set(_after(doc,"Conclusions"),"This study compared architecture-level temporal non-anticipation with loss-level temporal-shape regularization at SN_001 and then tested three core architectures at topology-selected mid-network and upstream nodes using identical rainfall forcing and 10 paired seeds. Three conclusions follow.")
    _set(_start(doc,"First, CA-LSTM"),"First, at SN_001 CA-LSTM improved pooled extreme RMSE by 31.7% and DASR by 24.7 percentage points relative to LSTM. The random-order control matched its RMSE but not its DASR, supporting a target-specific contribution of chronological organization to hydrograph direction.")
    _set(_start(doc,"Second, smoothness"),"Second, the added-node results were not uniform. At SN_032, causal order improved DASR without a significant RMSE advantage; at SN_044, it improved RMSE relative to LSTM but reduced DASR relative to both comparators. Surrogate architecture should therefore be selected and validated at the intended hydraulic nodes.")
    _set(_start(doc,"Third, observed-event"),"Third, temporal-shape penalties did not add a robust benefit at SN_001, and observed-event ranking remained metric dependent. Together with the cross-node reversal, this demonstrates why SWMM surrogates require multiple hydrologically interpretable endpoints rather than a single aggregate error measure.")
    _set(_start(doc,"Limitations are the single network"),"Limitations are the single drainage network, Chicago-only synthetic forcing, three target nodes, fixed regularization weights, 10 seeds, and the absence of datum-aligned observed depth at SN_032 and SN_044. The cross-node test strengthens within-network evidence but is not cross-network validation. Temporal causal attention does not enforce mass conservation, conduit connectivity, or dynamic-wave equations.")
    _set(_start(doc,"The source code, experiment configuration"),"The source code, experiment configuration, 140 trained checkpoints, node-specific cached events, complete metric files, node-selection audit, tables, and figures supporting this study are provided in the accompanying reproducibility archive. Observed workbooks are included only subject to the original data-sharing permissions.")
    _set(_start(doc,"The accompanying archive contains"),"The accompanying archive contains source code, the environment specification, SHA-256 cache manifests, 140 checkpoints and histories, event- and seed-level metrics, the observed-data and node-selection audits, three manuscript tables, and seven submission-ready TIFF figures.")
    _add_table3(doc,summary); doc.add_paragraph("Fig. 7. Cross-node robustness under pooled extreme rainfall.")
    doc.core_properties.title=TITLE; output.parent.mkdir(parents=True,exist_ok=True); doc.save(output); return output


def revise_response(source,output):
    doc=Document(source); _set(doc.paragraphs[1],TITLE)
    _set(_start(doc,"Dear Editor,"),"Dear Editor,\n\nThank you for the initial assessment and for inviting a substantially revised new submission. In addition to the leakage-free 10-seed ablation and observed-data audit, we completed a topology-prespecified cross-node robustness experiment. The revised manuscript centers the hydraulic question of when temporal non-anticipation helps SWMM hydrograph emulation and reports the observed node-dependent limits.")
    findings=_exact(doc,"Revised Main Findings")
    h=findings.insert_paragraph_before("Additional Cross-Node Robustness Revision",style="Heading 1"); _black(h)
    h.paragraph_format.space_before=Pt(12); h.paragraph_format.space_after=Pt(8); h.paragraph_format.keep_with_next=True
    additions=[
        "We audited all 49 junctions before training and selected SN_032 as the connected mid-network node and SN_044 as the longest-path upstream node. Selection used downstream path, contributing area, elevation, depth, and conduit attributes; no model result was used.",
        "The same 200 development and 60 extreme rainfall events were replayed at both nodes, producing 520 additional SWMM simulations. LSTM, RandomMaskLSTM, and CA-LSTM were trained with 10 paired seeds, producing 60 additional checkpoints with node and cache hashes in their fingerprints.",
        "The added evidence is reported without a universal-superiority claim: CA-LSTM improved DASR at SN_032, whereas at SN_044 it improved RMSE relative to LSTM but had lower DASR than both controls. Table 3, Fig. 7, the abstract, methods, discussion, conclusions, and limitations now state this node-by-metric interaction explicitly."]
    for text in additions:
        p=findings.insert_paragraph_before(text,style="Normal"); p.alignment=WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.left_indent=Inches(0); p.paragraph_format.first_line_indent=Inches(0)
        p.paragraph_format.space_before=Pt(0); p.paragraph_format.space_after=Pt(7); p.paragraph_format.line_spacing=1.15
    for p in doc.paragraphs[2:]: p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    output.parent.mkdir(parents=True,exist_ok=True); doc.save(output); return output


def main():
    p=argparse.ArgumentParser(); p.add_argument("--source-manuscript",type=Path,required=True); p.add_argument("--source-response",type=Path,required=True); p.add_argument("--evidence-root",type=Path,required=True); p.add_argument("--output",type=Path,required=True); a=p.parse_args()
    print(revise_manuscript(a.source_manuscript,a.evidence_root,a.output/"Manuscript_CA-LSTM_JHE_Final.docx")); print(revise_response(a.source_response,a.output/"Response_to_Editor_JHE_Final.docx"))


if __name__=="__main__": main()
