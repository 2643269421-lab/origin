"""Topology-only audit and prespecified cross-node selection for the SWMM network."""

from __future__ import annotations

from pathlib import Path
import pandas as pd


def _sections(path: str | Path) -> dict[str, list[list[str]]]:
    current = None
    sections: dict[str, list[list[str]]] = {}
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].upper(); sections.setdefault(current, []); continue
        if not line or line.startswith(";") or current is None:
            continue
        sections[current].append(line.split())
    return sections


def audit_nodes(template_path: str | Path) -> pd.DataFrame:
    data = _sections(template_path)
    junctions = {r[0]: {"Elevation_m": float(r[1]), "MaxDepth_m": float(r[2])}
                 for r in data["JUNCTIONS"]}
    conduits = {r[0]: {"From": r[1], "To": r[2], "Length_m": float(r[3])}
                for r in data["CONDUITS"]}
    diameters = {r[0]: float(r[2]) for r in data["XSECTIONS"] if len(r) > 2}
    outgoing = {node: [] for node in junctions}
    incoming = {node: [] for node in junctions}
    for name, edge in conduits.items():
        if edge["From"] in outgoing: outgoing[edge["From"]].append(name)
        if edge["To"] in incoming: incoming[edge["To"]].append(name)
    local = {node: 0.0 for node in junctions}
    for row in data["SUBCATCHMENTS"]:
        if row[2] in local: local[row[2]] += float(row[3])

    paths: dict[str, tuple[int, float]] = {}
    for start in junctions:
        node, hops, length, seen = start, 0, 0.0, set()
        while outgoing.get(node):
            edge_name = sorted(outgoing[node])[0]
            if edge_name in seen: raise ValueError("cycle in conduit topology")
            seen.add(edge_name); edge = conduits[edge_name]
            hops += 1; length += edge["Length_m"]; node = edge["To"]
        paths[start] = (hops, length)

    contributing = {node: 0.0 for node in junctions}
    for source, area in local.items():
        node, seen = source, set()
        while node in junctions and node not in seen:
            seen.add(node); contributing[node] += area
            if not outgoing.get(node): break
            node = conduits[sorted(outgoing[node])[0]]["To"]

    rows = []
    for node, attrs in junctions.items():
        first = sorted(outgoing[node])[0] if outgoing[node] else None
        rows.append({"Node": node, **attrs, "LocalArea_ha": local[node],
                     "ContributingArea_ha": contributing[node],
                     "UpstreamDegree": len(incoming[node]),
                     "DownstreamHops": paths[node][0],
                     "DownstreamLength_m": paths[node][1],
                     "DownstreamDiameter_m": diameters.get(first, float("nan"))})
    return pd.DataFrame(rows).sort_values("Node").reset_index(drop=True)


def select_cross_nodes(audit: pd.DataFrame) -> dict[str, str]:
    """Apply the topology-only rule fixed before any added-node training."""
    upstream = audit.sort_values(["DownstreamHops", "DownstreamLength_m", "Node"],
                                 ascending=[False, False, True]).iloc[0]["Node"]
    # Mid-network target: a confluence (at least two direct upstream links),
    # neither outlet-adjacent nor in the longest-path headwater tail.
    middle = audit[(audit["UpstreamDegree"] >= 2) & audit["DownstreamHops"].between(8, 12)]
    midstream = middle.sort_values(["ContributingArea_ha", "DownstreamHops", "Node"],
                                   ascending=[False, False, True]).iloc[0]["Node"]
    return {"midstream": str(midstream), "upstream": str(upstream)}


def write_node_audit(template_path: str | Path, output_dir: str | Path) -> dict[str, Path]:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    audit = audit_nodes(template_path); selected = select_cross_nodes(audit)
    audit_path = out / "node_topology_audit.csv"; audit.to_csv(audit_path, index=False, encoding="utf-8-sig")
    selection = audit[audit.Node.isin(selected.values())].copy()
    selection.insert(0, "Role", selection.Node.map({v: k for k, v in selected.items()}))
    selection_path = out / "selected_nodes.csv"; selection.to_csv(selection_path, index=False, encoding="utf-8-sig")
    return {"audit": audit_path, "selection": selection_path}
