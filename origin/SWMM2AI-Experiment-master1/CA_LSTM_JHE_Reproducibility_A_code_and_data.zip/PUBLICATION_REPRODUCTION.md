# Publication Experiment Reproduction Guide

## JHE cross-node extension

The final revision adds topology-selected nodes SN_032 and SN_044. `publication_nodes.py` records the selection audit; `publication_cache.build_node_caches` replays the original rainfall without regeneration; `cross_node_training.py` runs the three-model, ten-seed paired experiment; and `cross_node_evaluation.py` produces event metrics, seed summaries, hydraulic diagnostics, Wilcoxon tests, Holm correction, and rank-biserial effects. The complete archive contains 60 added-node and 80 original checkpoints.

This archive reproduces the paired 10-seed SWMM surrogate experiment reported in
`Manuscript_CA-LSTM_Revised.docx`. It contains the source code, SWMM input model,
observed-event workbooks, cached simulator output, trained checkpoints, complete metrics,
tables, and submission figures.

## 1. Environment

Recommended: Python 3.12 and `uv`.

```bash
uv sync --dev
```

Without `uv`, create a Python 3.12 virtual environment and install the dependencies listed
in `pyproject.toml`. The experiment uses the packaged `swmm-toolkit` solver when a system
SWMM executable is unavailable. On Windows, `runswmm.exe` can also be discovered from the
project directory or `PATH`.

Run the test suite before reproducing the experiment:

```bash
uv run pytest -q
```

## 2. Archived experiment design

- Synthetic development pool: 200 Chicago storms, return periods no greater than 10 years.
- Independent extremes: 15 events each at T = 20, 30, 50, and 100 years.
- Sequence: 288 five-minute steps (24 h).
- Per-seed split: 80% training, 10% validation, 10% held-out in-distribution test.
- Main models: LSTM, AttentionLSTM, RandomMaskLSTM, CA-LSTM, CA+SmoothLoss,
  CA+PeakTimeLoss, and PCCA-LSTM.
- Appendix control: GRU.
- Seeds: 42, 123, 456, 789, 1024, 2048, 3072, 4096, 5120, and 6144.
- Training: two recurrent layers, hidden size 64, dropout 0.3, batch size 32, Adam learning
  rate 0.001, at most 100 epochs, and early-stopping patience 15.
- Observed archive: 100 workbooks audited; 97 complete events included and three incomplete
  events excluded without interpolation.

The already generated evidence is under `output/publication_final/`. Regeneration is only
needed when source code, data, or experimental settings change.

## 3. Rebuild the SWMM caches

From the project root, run:

```bash
uv run python - <<'PY'
from publication_cache import build_event_caches

build_event_caches(
    output_dir="output/publication_final/data_cache",
    template_path="template.inp",
    seed=20260820,
    n_train=200,
    extreme_return_periods=(20, 30, 50, 100),
    n_test_per_return_period=15,
    sequence_length=288,
    time_step_minutes=5,
    min_duration_hours=1.0,
    max_duration_hours=6.0,
)
PY
```

Any failed or malformed SWMM event stops cache construction. Successful cache files and
their SHA-256 digests are recorded in `output/publication_final/data_cache/cache_manifest.json`.

## 4. Train all checkpoints

Main-text models:

```bash
uv run python publication_training.py --mode full \
  --cache-dir output/publication_final/data_cache \
  --output output/publication_final/training \
  --models LSTM AttentionLSTM RandomMaskLSTM CA-LSTM CA+SmoothLoss CA+PeakTimeLoss PCCA-LSTM \
  --seeds 42 123 456 789 1024 2048 3072 4096 5120 6144 \
  --epochs 100 --hidden-size 64 --patience 15
```

Appendix GRU:

```bash
uv run python publication_training.py --mode full \
  --cache-dir output/publication_final/data_cache \
  --output output/publication_final/training \
  --models GRU \
  --seeds 42 123 456 789 1024 2048 3072 4096 5120 6144 \
  --epochs 100 --hidden-size 64 --patience 15
```

Checkpoint reuse is safe: a checkpoint is skipped only when its stored fingerprint matches
the architecture/loss specification, seed, settings, split indices, fitted scalers, input
array hashes, and relevant source-file hashes.

## 5. Evaluate, test, and generate manuscript outputs

```bash
uv run python publication_evaluation.py \
  --training-dir output/publication_final/training \
  --cache-dir output/publication_final/data_cache \
  --data-dir "Actual Rainfall_Water Level" \
  --output output/publication_final/evaluation

uv run python publication_tables.py \
  --seed-metrics output/publication_final/evaluation/seed_metrics.csv \
  --output output/publication_final/tables

uv run python publication_figures.py \
  --seed-metrics output/publication_final/evaluation/seed_metrics.csv \
  --output output/publication_final/figures

uv run python tools/revise_manuscript.py
```

The statistical file `paired_tests.csv` contains paired Wilcoxon tests on seed means and
Holm-adjusted p-values. `real_event_exclusions.csv` records every observed workbook's
inclusion decision. Observed magnitude RMSE/NSE is not interpreted because the sensor level
datum is not aligned with SWMM relative depth.

## 6. Evidence map

| Purpose | File or directory |
|---|---|
| Raw SWMM arrays and hashes | `output/publication_final/data_cache/` |
| Training histories and 80 checkpoints | `output/publication_final/training/` |
| Event-level metrics | `output/publication_final/evaluation/event_metrics.csv` |
| Seed-level metrics | `output/publication_final/evaluation/seed_metrics.csv` |
| Paired tests and Holm adjustment | `output/publication_final/evaluation/paired_tests.csv` |
| Observed-data audit | `output/publication_final/evaluation/real_event_exclusions.csv` |
| Hydraulic response diagnostics | `output/publication_final/evaluation/hydraulic_event_characteristics.csv` |
| Manuscript tables | `output/publication_final/tables/` |
| PNG and TIFF figures | `output/publication_final/figures/` |
| Revised paper and editor response | `deliverables/` |

## 7. Main numerical checks

Across T = 20–100, CA-LSTM RMSE is 0.00713 m versus 0.01044 m for LSTM, and
DASR is 69.9% versus 45.2%. Both paired contrasts have Holm-adjusted p = 0.0098.
RandomMaskLSTM and CA-LSTM are statistically indistinguishable in RMSE (adjusted p = 1.000),
but CA-LSTM has 12.7 percentage points higher DASR (adjusted p = 0.0098). PCCA-LSTM does not
significantly differ from CA-LSTM after multiplicity correction (RMSE adjusted p = 0.0820).
