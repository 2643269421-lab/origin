"""Generate consistently named, CSV-driven publication figures."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd


FIGURE_CAPTIONS = {
    1: "Fig. 1. Leakage-free experimental framework and evidence flow",
    2: "Fig. 2. Model performance across extreme rainfall return periods",
    3: "Fig. 3. Overall RMSE comparison for the seven main-text models",
    4: "Fig. 4. Paired-seed comparison of LSTM and CA-LSTM",
    5: "Fig. 5. Loss-regularization ablation within the causal architecture",
    6: "Fig. 6. Performance on complete independently observed rainfall events",
}

FIGURE_FILENAMES = {
    1: "Fig1_ExperimentalFramework",
    2: "Fig2_ExtremeReturnPeriodTrends",
    3: "Fig3_SevenModelRMSE",
    4: "Fig4_PairedSeedComparison",
    5: "Fig5_LossAblation",
    6: "Fig6_ObservedEventPerformance",
}

COLORS = {
    "LSTM": "#4C78A8", "AttentionLSTM": "#F58518",
    "RandomMaskLSTM": "#B279A2", "CA-LSTM": "#00A087",
    "CA+SmoothLoss": "#72B7B2", "CA+PeakTimeLoss": "#E45756",
    "PCCA-LSTM": "#9D755D",
}


def required_columns(kind: str) -> set[str]:
    if kind != "seed_metrics":
        raise ValueError(f"unknown figure input: {kind}")
    return {"Model", "Seed", "Dataset", "RMSE", "DASR", "PeakIdxError"}


def _style() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.alpha": 0.22, "grid.linewidth": 0.6,
    })


def _save(fig, number: int, output_dir: Path, *, caption=None, stem=None) -> dict:
    caption = caption or FIGURE_CAPTIONS[number]
    fig.suptitle(caption, fontsize=11, fontweight="bold", y=0.995)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    stem = stem or FIGURE_FILENAMES[number]
    png = output_dir / f"{stem}.png"
    tif = output_dir / f"{stem}.tif"
    fig.savefig(png, dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(tif, dpi=300, bbox_inches="tight", facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    return {
        "caption": caption, "png": str(png), "tif": str(tif),
        "png_sha256": sha256(png.read_bytes()).hexdigest(),
        "tif_sha256": sha256(tif.read_bytes()).hexdigest(),
    }


def _framework_figure():
    fig, ax = plt.subplots(figsize=(9, 3.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    labels = [
        ("Synthetic rainfall\n(train RP <= 10 yr)", 0.02),
        ("SWMM reference\nwater depth", 0.22),
        ("Train-only scaling\nand paired splits", 0.42),
        ("Seven models\n10 fixed seeds", 0.62),
        ("Extreme + observed\nevaluation", 0.82),
    ]
    for label, x in labels:
        box = FancyBboxPatch(
            (x, 0.34), 0.16, 0.32, boxstyle="round,pad=0.02",
            facecolor="#E8F3F1", edgecolor="#008C7A", linewidth=1.4,
        )
        ax.add_patch(box)
        ax.text(x + 0.08, 0.50, label, ha="center", va="center", fontsize=9)
        if x < 0.8:
            ax.annotate("", xy=(x + 0.20, 0.50), xytext=(x + 0.17, 0.50),
                        arrowprops=dict(arrowstyle="->", color="#475569", lw=1.5))
    ax.text(0.50, 0.17, "Raw event metrics -> seed summaries -> paired tests -> manuscript",
            ha="center", color="#334155", fontsize=9)
    return fig


def _extreme_trends(seed_metrics: pd.DataFrame):
    subset = seed_metrics[seed_metrics["Dataset"].str.match(r"extreme_T\d+$")].copy()
    subset["ReturnPeriod"] = subset["Dataset"].str.extract(r"(\d+)").astype(int)
    models = ["LSTM", "AttentionLSTM", "RandomMaskLSTM", "CA-LSTM", "PCCA-LSTM"]
    summary = subset.groupby(["Model", "ReturnPeriod"], as_index=False)[["RMSE", "DASR"]].mean()
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.8))
    for model in models:
        values = summary[summary["Model"] == model].sort_values("ReturnPeriod")
        if values.empty:
            continue
        axes[0].plot(values["ReturnPeriod"], values["RMSE"], marker="o", label=model,
                     color=COLORS[model], linewidth=1.8)
        axes[1].plot(values["ReturnPeriod"], values["DASR"], marker="o", label=model,
                     color=COLORS[model], linewidth=1.8)
    axes[0].set(xlabel="Return period (yr)", ylabel="RMSE (m)")
    axes[1].set(xlabel="Return period (yr)", ylabel="DASR (%)")
    axes[1].legend(frameon=False, fontsize=7, ncol=1)
    return fig


def _seven_model_rmse(seed_metrics: pd.DataFrame):
    subset = seed_metrics[seed_metrics["Dataset"] == "extreme_all"]
    summary = subset.groupby("Model")["RMSE"].agg(["mean", "std"])
    order = list(COLORS)
    summary = summary.reindex(order)
    fig, ax = plt.subplots(figsize=(8.5, 4.0))
    positions = np.arange(len(order))
    ax.bar(positions, summary["mean"], yerr=summary["std"].fillna(0), capsize=3,
           color=[COLORS[name] for name in order], edgecolor="white")
    ax.set_xticks(positions, order, rotation=22, ha="right")
    ax.set_ylabel("RMSE (m)")
    return fig


def _paired_seed(seed_metrics: pd.DataFrame):
    subset = seed_metrics[
        (seed_metrics["Dataset"] == "extreme_all")
        & seed_metrics["Model"].isin(["LSTM", "CA-LSTM"])
    ]
    fig, axes = plt.subplots(1, 2, figsize=(8, 3.8))
    for ax, metric, ylabel in zip(axes, ("RMSE", "DASR"), ("RMSE (m)", "DASR (%)")):
        pivot = subset.pivot(index="Seed", columns="Model", values=metric).dropna()
        for _, row in pivot.iterrows():
            ax.plot([0, 1], [row["LSTM"], row["CA-LSTM"]], color="#94A3B8", alpha=0.75)
        ax.scatter(np.zeros(len(pivot)), pivot["LSTM"], color=COLORS["LSTM"], zorder=3)
        ax.scatter(np.ones(len(pivot)), pivot["CA-LSTM"], color=COLORS["CA-LSTM"], zorder=3)
        ax.set_xticks([0, 1], ["LSTM", "CA-LSTM"])
        ax.set_ylabel(ylabel)
    return fig


def _loss_ablation(seed_metrics: pd.DataFrame):
    names = ["CA-LSTM", "CA+SmoothLoss", "CA+PeakTimeLoss", "PCCA-LSTM"]
    subset = seed_metrics[
        (seed_metrics["Dataset"] == "extreme_all") & seed_metrics["Model"].isin(names)
    ]
    summary = subset.groupby("Model")[["RMSE", "DASR"]].agg(["mean", "std"]).reindex(names)
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.8))
    for ax, metric, ylabel in zip(axes, ("RMSE", "DASR"), ("RMSE (m)", "DASR (%)")):
        ax.bar(
            np.arange(len(names)), summary[(metric, "mean")],
            yerr=summary[(metric, "std")], capsize=3,
            color=[COLORS[name] for name in names],
        )
        ax.set_xticks(np.arange(len(names)), names, rotation=20, ha="right")
        ax.set_ylabel(ylabel)
    return fig


def _observed_performance(seed_metrics: pd.DataFrame):
    subset = seed_metrics[seed_metrics["Dataset"] == "real_observed"]
    summary = subset.groupby("Model")[["DASR", "PeakIdxError"]].agg(["mean", "std"]).reindex(list(COLORS))
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.8))
    names = list(summary.index)
    for ax, metric, ylabel in zip(
        axes, ("DASR", "PeakIdxError"), ("DASR (%)", "Peak timing error (steps)")
    ):
        ax.barh(
            np.arange(len(names)), summary[(metric, "mean")],
            xerr=summary[(metric, "std")], capsize=3,
            color=[COLORS[name] for name in names],
        )
        ax.set_yticks(np.arange(len(names)), names)
        ax.invert_yaxis()
        ax.set_xlabel(ylabel)
    return fig


def _cross_node_robustness(seed_metrics: pd.DataFrame):
    names = ["LSTM", "RandomMaskLSTM", "CA-LSTM"]
    subset = seed_metrics[(seed_metrics.Dataset == "extreme_all") & seed_metrics.Model.isin(names)]
    nodes = sorted(subset.Node.unique())
    summary = subset.groupby(["Node", "Model"])[["RMSE", "DASR"]].agg(["mean", "std"])
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.9)); x=np.arange(len(nodes)); width=.24
    for i, model in enumerate(names):
        positions=x+(i-1)*width
        for ax, metric, ylabel in zip(axes, ("RMSE", "DASR"), ("RMSE (m)", "DASR (%)")):
            means=[summary.loc[(n,model),(metric,"mean")] for n in nodes]
            stds=[summary.loc[(n,model),(metric,"std")] for n in nodes]
            ax.bar(positions, means, width=width, yerr=np.nan_to_num(stds), capsize=3,
                   label=model, color=COLORS[model], edgecolor="white")
            ax.set_ylabel(ylabel); ax.set_xticks(x,nodes)
    axes[1].legend(frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(.5,-.16), ncol=3)
    return fig


def generate_cross_node_figure(seed_metrics: pd.DataFrame, output_dir: str | Path) -> Path:
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True); _style()
    caption="Fig. 7. Cross-node robustness under pooled extreme rainfall"
    item=_save(_cross_node_robustness(seed_metrics),7,out,caption=caption,stem="Fig7_CrossNodeRobustness")
    path=out/"cross_node_figure_manifest.json"
    path.write_text(json.dumps({"figures":{"7":item}},indent=2),encoding="utf-8"); return path


def generate_publication_figures(seed_metrics: pd.DataFrame, output_dir: str | Path) -> Path:
    missing = required_columns("seed_metrics") - set(seed_metrics.columns)
    if missing:
        raise ValueError(f"seed metrics missing columns: {sorted(missing)}")
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    _style()
    builders = {
        1: lambda: _framework_figure(),
        2: lambda: _extreme_trends(seed_metrics),
        3: lambda: _seven_model_rmse(seed_metrics),
        4: lambda: _paired_seed(seed_metrics),
        5: lambda: _loss_ablation(seed_metrics),
        6: lambda: _observed_performance(seed_metrics),
    }
    manifest = {"figures": {str(number): _save(builder(), number, destination)
                             for number, builder in builders.items()}}
    manifest_path = destination / "figure_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-metrics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = generate_publication_figures(pd.read_csv(args.seed_metrics), args.output)
    print(f"Figure manifest: {manifest}")


if __name__ == "__main__":
    main()
