"""Paired, deterministic training for the publication model set."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import argparse
import csv
import json
from pathlib import Path
import random

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from attention import AttentionLSTM, CausalAttentionLSTM, RandomMaskAttentionLSTM
from gru import SimpleGRU
from lstm import SimpleLSTM
from physics_loss import PhysicallyConsistentLoss
from publication_config import (
    APPENDIX_MODEL_SPECS,
    BATCH_SIZE,
    EARLY_STOPPING_PATIENCE,
    LEARNING_RATE,
    MAIN_MODEL_SPECS,
    MAX_EPOCHS,
    ModelSpec,
    SEEDS,
    SEQUENCE_LENGTH,
    TIME_STEP_MINUTES,
)
from publication_data import PreparedDataset, load_event_cache, make_split_indices, prepare_split


@dataclass(frozen=True)
class TrainingSettings:
    epochs: int = 100
    batch_size: int = 32
    learning_rate: float = 0.001
    patience: int = 15
    hidden_size: int = 64
    num_layers: int = 2
    dropout: float = 0.3
    device: str = "cpu"


@dataclass(frozen=True)
class TrainingRecord:
    model_name: str
    seed: int
    best_epoch: int
    best_val_loss: float
    checkpoint_path: str
    history_path: str
    config_sha256: str


def _set_deterministic_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


def build_model(
    spec: ModelSpec, *, hidden_size: int = 128, num_layers: int = 2,
    dropout: float = 0.3,
) -> nn.Module:
    common = dict(
        input_size=1, hidden_size=hidden_size, num_layers=num_layers,
        output_size=1, dropout=dropout,
    )
    architectures = {
        "lstm": SimpleLSTM,
        "gru": SimpleGRU,
        "attention": AttentionLSTM,
        "random_mask": RandomMaskAttentionLSTM,
        "causal_attention": CausalAttentionLSTM,
    }
    try:
        model_class = architectures[spec.architecture]
    except KeyError as exc:
        raise ValueError(f"unknown architecture: {spec.architecture}") from exc
    return model_class(**common)


def _array_hash(value: np.ndarray) -> str:
    array = np.ascontiguousarray(np.asarray(value))
    digest = sha256()
    digest.update(str(array.dtype).encode())
    digest.update(str(array.shape).encode())
    digest.update(array.tobytes())
    return digest.hexdigest()


def _scaler_payload(scaler) -> dict[str, list[float]]:
    return {
        name: np.asarray(getattr(scaler, name), dtype=float).reshape(-1).tolist()
        for name in ("data_min_", "data_max_", "scale_", "min_")
    }


def _source_hashes() -> dict[str, str]:
    root = Path(__file__).resolve().parent
    names = ("publication_training.py", "attention.py", "lstm.py", "gru.py", "physics_loss.py")
    return {name: sha256((root / name).read_bytes()).hexdigest() for name in names}


def configuration_fingerprint(
    spec: ModelSpec, dataset: PreparedDataset, seed: int,
    settings: TrainingSettings, provenance: dict | None = None,
) -> tuple[str, dict]:
    payload = {
        "model": asdict(spec),
        "seed": int(seed),
        "settings": asdict(settings),
        "split_indices": dataset.split_indices,
        "rain_scaler": _scaler_payload(dataset.rain_scaler),
        "water_scaler": _scaler_payload(dataset.water_scaler),
        "train_x_sha256": _array_hash(dataset.train_x),
        "train_y_sha256": _array_hash(dataset.train_y),
        "source_sha256": _source_hashes(),
        "provenance": provenance or {},
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return sha256(encoded).hexdigest(), payload


def checkpoint_matches(path: str | Path, expected_fingerprint: str) -> bool:
    checkpoint_path = Path(path)
    if not checkpoint_path.is_file():
        return False
    try:
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    except Exception:
        return False
    return checkpoint.get("config_sha256") == expected_fingerprint


def _loader(
    x: np.ndarray, y: np.ndarray, *, batch_size: int, shuffle: bool,
    seed: int,
) -> DataLoader:
    inputs = torch.as_tensor(x, dtype=torch.float32).unsqueeze(-1)
    targets = torch.as_tensor(y, dtype=torch.float32).unsqueeze(-1)
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        TensorDataset(inputs, targets), batch_size=batch_size, shuffle=shuffle,
        generator=generator if shuffle else None,
    )


def _criterion(spec: ModelSpec) -> nn.Module:
    if spec.lambda_smooth or spec.lambda_peak:
        return PhysicallyConsistentLoss(
            lambda_smooth=spec.lambda_smooth,
            lambda_peak=spec.lambda_peak,
            lambda_mass=0.0,
            peak_temperature=spec.peak_temperature,
        )
    return nn.MSELoss()


def _safe_name(name: str) -> str:
    return name.lower().replace("+", "_plus_").replace("-", "_").replace(" ", "_")


def train_one(
    spec: ModelSpec, dataset: PreparedDataset, seed: int,
    output_dir: str | Path, settings: TrainingSettings | None = None,
    provenance: dict | None = None,
) -> TrainingRecord:
    """Train one paired model and persist its best checkpoint and full history."""
    settings = settings or TrainingSettings()
    if len(dataset.train_x) == 0 or len(dataset.val_x) == 0:
        raise ValueError("training and validation partitions must both be non-empty")
    _set_deterministic_seed(seed)
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    stem = f"{_safe_name(spec.name)}_seed{seed}"
    checkpoint_path = destination / f"{stem}.pth"
    history_path = destination / f"{stem}_history.csv"
    fingerprint, fingerprint_payload = configuration_fingerprint(
        spec, dataset, seed, settings, provenance
    )

    if checkpoint_matches(checkpoint_path, fingerprint) and history_path.is_file():
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        return TrainingRecord(
            spec.name, seed, int(checkpoint["best_epoch"]),
            float(checkpoint["best_val_loss"]), str(checkpoint_path),
            str(history_path), fingerprint,
        )

    device = torch.device(settings.device)
    model = build_model(
        spec, hidden_size=settings.hidden_size, num_layers=settings.num_layers,
        dropout=settings.dropout,
    ).to(device)
    criterion = _criterion(spec)
    optimizer = torch.optim.Adam(model.parameters(), lr=settings.learning_rate)
    train_loader = _loader(
        dataset.train_x, dataset.train_y, batch_size=settings.batch_size,
        shuffle=True, seed=seed,
    )
    val_loader = _loader(
        dataset.val_x, dataset.val_y, batch_size=settings.batch_size,
        shuffle=False, seed=seed,
    )

    best_loss = float("inf")
    best_epoch = 0
    epochs_without_improvement = 0
    history: list[dict] = []
    for epoch in range(1, settings.epochs + 1):
        model.train()
        train_total = 0.0
        train_batches = 0
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(inputs), targets)
            loss.backward()
            optimizer.step()
            train_total += float(loss.detach().cpu())
            train_batches += 1

        model.eval()
        val_total = 0.0
        val_batches = 0
        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                val_total += float(criterion(model(inputs), targets).detach().cpu())
                val_batches += 1
        train_loss = train_total / train_batches
        val_loss = val_total / val_batches
        if not np.isfinite(train_loss) or not np.isfinite(val_loss):
            raise FloatingPointError(f"non-finite loss for {spec.name} at epoch {epoch}")
        history.append({"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss})

        if val_loss < best_loss:
            best_loss = val_loss
            best_epoch = epoch
            epochs_without_improvement = 0
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "model_spec": asdict(spec),
                    "settings": asdict(settings),
                    "seed": seed,
                    "best_epoch": best_epoch,
                    "best_val_loss": best_loss,
                    "config_sha256": fingerprint,
                    "fingerprint_payload": fingerprint_payload,
                },
                checkpoint_path,
            )
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= settings.patience:
                break

    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=("epoch", "train_loss", "val_loss"))
        writer.writeheader()
        writer.writerows(history)
    return TrainingRecord(
        spec.name, seed, best_epoch, best_loss, str(checkpoint_path),
        str(history_path), fingerprint,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("smoke", "full"), default="smoke")
    parser.add_argument("--models", nargs="+", default=["LSTM", "CA-LSTM"])
    parser.add_argument("--seeds", nargs="+", type=int, default=[SEEDS[0]])
    parser.add_argument("--events", type=int, default=12)
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--hidden-size", type=int)
    parser.add_argument("--patience", type=int)
    parser.add_argument("--cache-dir", type=Path)
    parser.add_argument("--output", type=Path, default=Path("output/publication/training"))
    args = parser.parse_args()

    specs = {**MAIN_MODEL_SPECS, **APPENDIX_MODEL_SPECS}
    unknown = [name for name in args.models if name not in specs]
    if unknown:
        parser.error(f"unknown model(s): {', '.join(unknown)}")

    sequence_length = 48 if args.mode == "smoke" else SEQUENCE_LENGTH
    event_count = args.events if args.mode == "smoke" else 200
    cache_dir = args.cache_dir or Path("output/publication/data_cache")
    train_cache = cache_dir / "train_events.npz"
    if not train_cache.is_file():
        from publication_cache import build_event_caches

        build_event_caches(
            output_dir=cache_dir,
            template_path=Path(__file__).with_name("template.inp"),
            seed=20260820,
            n_train=event_count,
            extreme_return_periods=(),
            n_test_per_return_period=1,
            sequence_length=sequence_length,
            time_step_minutes=TIME_STEP_MINUTES,
            min_duration_hours=1.0,
            max_duration_hours=1.0 if args.mode == "smoke" else 6.0,
        )
    rainfall, water, _ = load_event_cache(train_cache)
    if len(rainfall) != event_count or rainfall.shape[1] != sequence_length:
        raise ValueError(
            f"cache shape {rainfall.shape} does not match requested "
            f"({event_count}, {sequence_length}); use a separate --cache-dir"
        )

    for seed in args.seeds:
        split = make_split_indices(len(rainfall), seed)
        dataset = prepare_split(
            rainfall, water, train_idx=split["train"], val_idx=split["val"],
            test_idx=split["test"],
        )
        settings = TrainingSettings(
            epochs=args.epochs or (2 if args.mode == "smoke" else MAX_EPOCHS),
            batch_size=2 if args.mode == "smoke" else BATCH_SIZE,
            learning_rate=LEARNING_RATE,
            patience=args.patience or (2 if args.mode == "smoke" else EARLY_STOPPING_PATIENCE),
            hidden_size=args.hidden_size or (8 if args.mode == "smoke" else 64),
            num_layers=1 if args.mode == "smoke" else 2,
            dropout=0.0 if args.mode == "smoke" else 0.3,
        )
        for name in args.models:
            record = train_one(specs[name], dataset, seed, args.output, settings)
            print(
                f"{record.model_name} seed={record.seed}: epoch={record.best_epoch}, "
                f"val={record.best_val_loss:.6g}, checkpoint={record.checkpoint_path}"
            )


if __name__ == "__main__":
    main()
