"""Hydrologic metrics and auditable parsing of observed storm records."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from publication_config import ModelSpec
from publication_data import load_event_cache
from publication_statistics import paired_test_table
from publication_training import TrainingSettings, build_model


OBSERVED_RAIN_COLUMN = "雨强(mm/hr)"
OBSERVED_WATER_COLUMN = "HUZU_STORM_L_01_液位"


def compute_metrics(prediction, target) -> dict[str, float | int]:
    pred = np.asarray(prediction, dtype=float).reshape(-1)
    obs = np.asarray(target, dtype=float).reshape(-1)
    if len(pred) == 0 or pred.shape != obs.shape:
        raise ValueError("prediction and target must be non-empty arrays of equal length")
    if not np.isfinite(pred).all() or not np.isfinite(obs).all():
        raise ValueError("prediction and target must contain only finite values")

    residual = pred - obs
    rmse = float(np.sqrt(np.mean(residual ** 2)))
    mae = float(np.mean(np.abs(residual)))
    denominator = float(np.sum((obs - np.mean(obs)) ** 2))
    variance_tolerance = np.finfo(float).eps * max(1.0, float(np.sum(obs ** 2)))
    nse = (
        float(1.0 - np.sum(residual ** 2) / denominator)
        if denominator > variance_tolerance else float("nan")
    )
    peak_error = float(np.max(pred) - np.max(obs))
    peak_idx_error = int(abs(int(np.argmax(pred)) - int(np.argmax(obs))))
    water_range = float(np.ptp(obs))
    range_tolerance = np.sqrt(np.finfo(float).eps) * max(1.0, float(np.max(np.abs(obs))))
    nrmse = float(rmse / water_range) if water_range > range_tolerance else float("nan")

    pred_diff = np.diff(pred)
    obs_diff = np.diff(obs)
    threshold = max(water_range * 1e-6, 1e-8)
    significant = np.abs(obs_diff) > threshold
    dasr = (
        float(np.mean(np.sign(pred_diff[significant]) == np.sign(obs_diff[significant])) * 100)
        if np.any(significant)
        else float("nan")
    )
    return {
        "RMSE": rmse,
        "MAE": mae,
        "NSE": nse,
        "R2": nse,
        "PeakError": peak_error,
        "PeakIdxError": peak_idx_error,
        "DASR": dasr,
        "NRMSE": nrmse,
    }


def compute_hydraulic_characteristics(
    rainfall_events, depth_events, *, time_step_minutes: int
) -> pd.DataFrame:
    """Summarize physically interpretable rainfall-to-depth response timing."""
    rain = np.asarray(rainfall_events, dtype=float)
    depth = np.asarray(depth_events, dtype=float)
    if rain.ndim != 2 or rain.shape != depth.shape:
        raise ValueError("rainfall and depth events must be matching two-dimensional arrays")
    rain_peak = np.argmax(rain, axis=1)
    depth_peak = np.argmax(depth, axis=1)
    lag_steps = depth_peak - rain_peak
    return pd.DataFrame({
        "Event": np.arange(len(rain)),
        "RainPeakIdx": rain_peak,
        "DepthPeakIdx": depth_peak,
        "ResponseLagSteps": lag_steps,
        "ResponseLagMinutes": lag_steps * int(time_step_minutes),
        "PeakRainfall_mm_h": np.max(rain, axis=1),
        "PeakDepth_m": np.max(depth, axis=1),
    })


def select_observed_columns(columns) -> tuple[str, str]:
    normalized = {str(column).strip(): column for column in columns}
    missing = [
        name for name in (OBSERVED_RAIN_COLUMN, OBSERVED_WATER_COLUMN)
        if name not in normalized
    ]
    if missing:
        raise ValueError("missing required observed column(s): " + ", ".join(missing))
    return normalized[OBSERVED_RAIN_COLUMN], normalized[OBSERVED_WATER_COLUMN]


def audit_real_data(
    data_dir: str | Path, output_path: str | Path, *, expected_rows: int = 288
) -> pd.DataFrame:
    """Record the inclusion decision for every workbook; never skip silently."""
    directory = Path(data_dir)
    records: list[dict] = []
    for path in sorted(directory.glob("*.xlsx")):
        record = {
            "file": path.name, "status": "excluded", "reason": "",
            "n_rows": 0, "rain_column": "", "water_column": "",
        }
        try:
            frame = pd.read_excel(path)
            rain_column, water_column = select_observed_columns(frame.columns)
            rain = pd.to_numeric(frame[rain_column], errors="coerce")
            water = pd.to_numeric(frame[water_column], errors="coerce")
            valid = rain.notna() & water.notna()
            valid_count = int(valid.sum())
            if valid_count != expected_rows:
                raise ValueError(
                    f"{valid_count} paired numeric observations; expected {expected_rows}"
                )
            record.update({
                "status": "included", "reason": "",
                "n_rows": valid_count, "rain_column": str(rain_column),
                "water_column": str(water_column),
            })
        except Exception as exc:
            record["reason"] = str(exc)
        records.append(record)
    if not records:
        records.append({
            "file": "", "status": "excluded", "reason": "no .xlsx files found",
            "n_rows": 0, "rain_column": "", "water_column": "",
        })
    audit = pd.DataFrame.from_records(records)
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(destination, index=False, encoding="utf-8-sig")
    return audit


def _transform(values: np.ndarray, scaler: dict) -> np.ndarray:
    return np.asarray(values, dtype=float) * float(scaler["scale_"][0]) + float(scaler["min_"][0])


def _inverse_transform(values: np.ndarray, scaler: dict) -> np.ndarray:
    return (np.asarray(values, dtype=float) - float(scaler["min_"][0])) / float(scaler["scale_"][0])


def _predict_events(model, rainfall: np.ndarray, rain_scaler: dict, water_scaler: dict,
                    batch_size: int = 32) -> np.ndarray:
    scaled = _transform(rainfall, rain_scaler)
    predictions: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(scaled), batch_size):
            inputs = torch.as_tensor(
                scaled[start:start + batch_size], dtype=torch.float32
            ).unsqueeze(-1)
            predictions.append(model(inputs).squeeze(-1).cpu().numpy())
    return _inverse_transform(np.concatenate(predictions, axis=0), water_scaler)


def _metric_rows(
    *, model_name: str, seed: int, dataset_name: str,
    predictions: np.ndarray, targets: np.ndarray, event_names=None,
) -> list[dict]:
    names = event_names if event_names is not None else range(len(predictions))
    return [
        {
            "Model": model_name, "Seed": seed, "Dataset": dataset_name,
            "Event": str(event_name), **compute_metrics(prediction, target),
        }
        for event_name, prediction, target in zip(names, predictions, targets)
    ]


def evaluate_experiment(
    *, training_dir: str | Path, cache_dir: str | Path,
    real_data_dir: str | Path, output_dir: str | Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Evaluate every compatible checkpoint and create all traceable CSV evidence."""
    training_path = Path(training_dir)
    cache_path = Path(cache_dir)
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    train_rain, train_water, train_metadata = load_event_cache(cache_path / "train_events.npz")
    audit = audit_real_data(
        real_data_dir, destination / "real_event_exclusions.csv",
        expected_rows=train_rain.shape[1],
    )
    included_names = audit.loc[audit["status"] == "included", "file"].tolist()
    extreme_caches = sorted(cache_path.glob("extreme_T*.npz"))
    if not extreme_caches:
        raise FileNotFoundError(f"no extreme_T*.npz caches found in {cache_path}")
    event_rows: list[dict] = []
    physical_tables: list[pd.DataFrame] = []
    train_physics = compute_hydraulic_characteristics(
        train_rain, train_water,
        time_step_minutes=int(train_metadata["time_step_minutes"]),
    )
    train_physics.insert(0, "Dataset", "training_RP_le_10")
    physical_tables.append(train_physics)
    for extreme_path in extreme_caches:
        rain, water, metadata = load_event_cache(extreme_path)
        physics = compute_hydraulic_characteristics(
            rain, water, time_step_minutes=int(metadata["time_step_minutes"])
        )
        physics.insert(0, "Dataset", f"extreme_T{metadata['return_period']}")
        physical_tables.append(physics)
    pd.concat(physical_tables, ignore_index=True).to_csv(
        destination / "hydraulic_event_characteristics.csv",
        index=False, encoding="utf-8-sig",
    )

    for checkpoint_path in sorted(training_path.glob("*.pth")):
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        required = {"model_spec", "settings", "seed", "fingerprint_payload", "model_state_dict"}
        if not required.issubset(checkpoint):
            raise ValueError(f"checkpoint lacks publication metadata: {checkpoint_path}")
        spec = ModelSpec(**checkpoint["model_spec"])
        settings = TrainingSettings(**checkpoint["settings"])
        model = build_model(
            spec, hidden_size=settings.hidden_size,
            num_layers=settings.num_layers, dropout=settings.dropout,
        )
        model.load_state_dict(checkpoint["model_state_dict"])
        seed = int(checkpoint["seed"])
        payload = checkpoint["fingerprint_payload"]
        rain_scaler = payload["rain_scaler"]
        water_scaler = payload["water_scaler"]

        test_indices = payload["split_indices"]["test"]
        predictions = _predict_events(
            model, train_rain[test_indices], rain_scaler, water_scaler
        )
        event_rows.extend(_metric_rows(
            model_name=spec.name, seed=seed, dataset_name="in_distribution",
            predictions=predictions, targets=train_water[test_indices],
            event_names=test_indices,
        ))

        for extreme_path in extreme_caches:
            rain, water, metadata = load_event_cache(extreme_path)
            return_period = metadata["return_period"]
            predictions = _predict_events(model, rain, rain_scaler, water_scaler)
            event_rows.extend(_metric_rows(
                model_name=spec.name, seed=seed,
                dataset_name=f"extreme_T{return_period}",
                predictions=predictions, targets=water,
            ))

        real_rain: list[np.ndarray] = []
        real_water: list[np.ndarray] = []
        valid_names: list[str] = []
        sequence_length = train_rain.shape[1]
        for filename in included_names:
            frame = pd.read_excel(Path(real_data_dir) / filename)
            rain_column, water_column = select_observed_columns(frame.columns)
            paired = pd.DataFrame({
                "rain": pd.to_numeric(frame[rain_column], errors="coerce"),
                "water": pd.to_numeric(frame[water_column], errors="coerce"),
            }).dropna()
            if len(paired) != sequence_length:
                raise ValueError(
                    f"{filename} has {len(paired)} valid rows; expected {sequence_length}"
                )
            real_rain.append(paired["rain"].to_numpy(dtype=float))
            real_water.append(paired["water"].to_numpy(dtype=float))
            valid_names.append(filename)
        if real_rain:
            predictions = _predict_events(
                model, np.asarray(real_rain), rain_scaler, water_scaler
            )
            event_rows.extend(_metric_rows(
                model_name=spec.name, seed=seed, dataset_name="real_observed",
                predictions=predictions, targets=np.asarray(real_water),
                event_names=valid_names,
            ))

    if not event_rows:
        raise FileNotFoundError(f"no publication checkpoints found in {training_path}")
    event_metrics = pd.DataFrame.from_records(event_rows)
    event_metrics.to_csv(destination / "event_metrics.csv", index=False, encoding="utf-8-sig")
    metric_columns = ["RMSE", "MAE", "NSE", "R2", "PeakError", "PeakIdxError", "DASR", "NRMSE"]
    seed_metrics = (
        event_metrics.groupby(["Model", "Seed", "Dataset"], as_index=False)[metric_columns]
        .mean(numeric_only=True)
    )
    extreme_all = (
        event_metrics[event_metrics["Dataset"].str.startswith("extreme_T")]
        .groupby(["Model", "Seed"], as_index=False)[metric_columns]
        .mean(numeric_only=True)
    )
    extreme_all["Dataset"] = "extreme_all"
    seed_metrics = pd.concat([seed_metrics, extreme_all], ignore_index=True)
    seed_metrics.to_csv(destination / "seed_metrics.csv", index=False, encoding="utf-8-sig")

    primary = [
        ("AttentionLSTM", "LSTM"),
        ("RandomMaskLSTM", "LSTM"),
        ("RandomMaskLSTM", "CA-LSTM"),
        ("CA-LSTM", "LSTM"),
        ("PCCA-LSTM", "CA-LSTM"),
    ]
    test_source = seed_metrics[seed_metrics["Dataset"] == "extreme_all"]
    paired_tables = [
        paired_test_table(test_source, metric=metric, comparisons=primary)
        for metric in ("RMSE", "DASR")
    ]
    paired_tests = pd.concat(paired_tables, ignore_index=True)
    paired_tests.to_csv(destination / "paired_tests.csv", index=False, encoding="utf-8-sig")
    return event_metrics, seed_metrics, paired_tests


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-real-data", action="store_true")
    parser.add_argument("--data-dir", type=Path, default=Path("Actual Rainfall_Water Level"))
    parser.add_argument(
        "--output", type=Path,
        default=Path("output/publication/evaluation/real_event_exclusions.csv"),
    )
    parser.add_argument("--training-dir", type=Path)
    parser.add_argument("--cache-dir", type=Path)
    args = parser.parse_args()
    if args.audit_real_data:
        audit = audit_real_data(args.data_dir, args.output)
        print(audit["status"].value_counts().to_string())
        print(f"Audit: {args.output}")
    elif args.training_dir and args.cache_dir:
        event_metrics, seed_metrics, paired_tests = evaluate_experiment(
            training_dir=args.training_dir, cache_dir=args.cache_dir,
            real_data_dir=args.data_dir, output_dir=args.output,
        )
        print(
            f"Evaluation complete: {len(event_metrics)} events, "
            f"{len(seed_metrics)} seed summaries, {len(paired_tests)} tests"
        )
    else:
        parser.error("use --audit-real-data or provide --training-dir and --cache-dir")


if __name__ == "__main__":
    main()
